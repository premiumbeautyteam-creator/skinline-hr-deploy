// hh.ru vacancy synchronization: import active employer vacancies into the
// local `vacancies` table and publish a local vacancy to hh.ru.
//
// Linkage between a local vacancy and its hh.ru vacancy id is tracked via
// external_refs (source='hh', externalType='vacancy'), mirroring the Avito
// pattern. Import is idempotent: re-running updates existing rows by ref.

import { storage } from "../storage.js";
import { HhClient, HhApiError } from "./hh.js";
import { mapVacancyToHh } from "./hh-mapper.js";

const SOURCE = "hh";

function formatSalary(salary: any): string {
  if (!salary) return "";
  const from = salary.from;
  const to = salary.to;
  const cur = (salary.currency ?? "RUR").toUpperCase();
  const sign = cur === "RUR" || cur === "RUB" ? "₽" : cur;
  if (from && to) return `${Number(from).toLocaleString("ru-RU")}–${Number(to).toLocaleString("ru-RU")} ${sign}`;
  if (from) return `от ${Number(from).toLocaleString("ru-RU")} ${sign}`;
  if (to) return `до ${Number(to).toLocaleString("ru-RU")} ${sign}`;
  return "";
}

/**
 * Import all active hh.ru employer vacancies into the local vacancies table.
 * Idempotent via external_refs(hh, vacancy). Returns counters.
 */
export async function importHhVacancies(): Promise<{
  total: number;
  created: number;
  updated: number;
  errors: string[];
}> {
  const integ = await storage.getIntegration(SOURCE);
  const errors: string[] = [];
  let created = 0;
  let updated = 0;
  let total = 0;

  if (!integ || integ.status !== "connected") {
    return { total, created, updated, errors: ["hh.ru не подключён"] };
  }

  const client = new HhClient(integ);
  const employerId = client.resolveEmployerId();
  if (!employerId) {
    return { total, created, updated, errors: ["employer_id не определён"] };
  }

  for (let page = 0; page < 20; page++) {
    let data: any;
    try {
      data = await client.listVacancies(employerId, { page, perPage: 100 });
    } catch (e: any) {
      errors.push(`page ${page}: ${e?.message ?? String(e)}`);
      break;
    }
    const items: any[] = data?.items ?? [];
    if (items.length === 0) break;
    total += items.length;

    for (const item of items) {
      const hhId = item?.id != null ? String(item.id) : null;
      if (!hhId) continue;
      try {
        const url = item?.alternate_url ?? `https://hh.ru/vacancy/${hhId}`;
        const city = item?.area?.name ?? "—";
        const salary = formatSalary(item?.salary);
        const existingRef = await storage.getExternalRef(SOURCE, "vacancy", hhId);

        if (existingRef) {
          await storage.updateVacancy(existingRef.entityId, {
            title: item?.name ?? "Вакансия с hh.ru",
            city,
            salary: salary || "—",
            externalUrl: url,
            status: item?.archived ? "closed" : "active",
            source: SOURCE,
          });
          updated++;
        } else {
          const v = await storage.createVacancy({
            title: item?.name ?? "Вакансия с hh.ru",
            city,
            salary: salary || "—",
            status: item?.archived ? "closed" : "active",
            description: `Импортировано с hh.ru. Источник: ${url}`,
            externalUrl: url,
            source: SOURCE,
          });
          await storage.createExternalRef({
            entityType: "vacancy",
            entityId: v.id,
            source: SOURCE,
            externalId: hhId,
            externalType: "vacancy",
            meta: JSON.stringify({ url }),
          });
          created++;
        }
      } catch (e: any) {
        errors.push(`vacancy ${hhId}: ${e?.message ?? String(e)}`);
      }
    }

    const pages = data?.pages ?? 1;
    if (page + 1 >= pages || items.length < 100) break;
  }

  console.log(`[hh_vacancies] import: total=${total} created=${created} updated=${updated} errors=${errors.length}`);
  return { total, created, updated, errors };
}

/** Default area (Москва=1) and professional role (other=40) if not resolvable. */
const DEFAULT_AREA_ID = "1";
const DEFAULT_ROLE_ID = "40";

/** Flatten the nested hh /areas tree into a name->id map. */
function flattenAreas(nodes: any[], acc: Map<string, string>): void {
  for (const n of nodes ?? []) {
    if (n?.name && n?.id != null) acc.set(String(n.name).toLowerCase(), String(n.id));
    if (Array.isArray(n?.areas) && n.areas.length) flattenAreas(n.areas, acc);
  }
}

async function resolveAreaId(client: HhClient, city: string | null | undefined): Promise<string> {
  if (!city || !city.trim()) return DEFAULT_AREA_ID;
  try {
    const tree = await client.getAreas();
    const map = new Map<string, string>();
    flattenAreas(Array.isArray(tree) ? tree : [tree], map);
    const hit = map.get(city.trim().toLowerCase());
    if (hit) return hit;
  } catch (e) {
    console.warn("[hh_vacancies] getAreas failed, using default area:", e);
  }
  return DEFAULT_AREA_ID;
}

/**
 * Publish a local vacancy to hh.ru (POST /vacancies). Stores the resulting
 * external_ref + external_url on success. hh.ru validation errors are surfaced
 * as a readable message. Publishing is paid — callers should confirm first.
 */
export async function publishVacancyToHh(localVacancyId: string): Promise<{
  ok: boolean;
  hhVacancyId?: string;
  externalUrl?: string;
  error?: string;
}> {
  const vacancy = await storage.getVacancy(localVacancyId);
  if (!vacancy) return { ok: false, error: "Вакансия не найдена" };

  // Already published? Don't create a duplicate.
  const existingRef = await storage.getExternalRefByEntity("vacancy", localVacancyId, SOURCE, "vacancy");
  if (existingRef) {
    return {
      ok: true,
      hhVacancyId: existingRef.externalId,
      externalUrl: vacancy.externalUrl ?? undefined,
      error: "Вакансия уже опубликована на hh.ru",
    };
  }

  const integ = await storage.getIntegration(SOURCE);
  if (!integ || integ.status !== "connected") {
    return { ok: false, error: "hh.ru не подключён. Подключите аккаунт в настройках." };
  }
  const client = new HhClient(integ);
  const employerId = client.resolveEmployerId();
  const areaId = await resolveAreaId(client, vacancy.city);
  const payload = mapVacancyToHh(vacancy, {
    areaId,
    professionalRoleId: DEFAULT_ROLE_ID,
    employerId,
  });

  try {
    const result = await client.createVacancy(payload);
    const hhVacancyId = result?.id != null ? String(result.id) : null;
    const externalUrl =
      result?.alternate_url ?? (hhVacancyId ? `https://hh.ru/vacancy/${hhVacancyId}` : null);

    if (hhVacancyId) {
      await storage.createExternalRef({
        entityType: "vacancy",
        entityId: localVacancyId,
        source: SOURCE,
        externalId: hhVacancyId,
        externalType: "vacancy",
        meta: JSON.stringify({ url: externalUrl, publishedAt: new Date().toISOString() }),
      }).catch(() => undefined);
    }
    await storage.updateVacancy(localVacancyId, {
      externalUrl: externalUrl ?? vacancy.externalUrl,
      source: vacancy.source ?? "manual",
    });

    console.log(`[hh_vacancies] published vacancy ${localVacancyId} -> hh ${hhVacancyId}`);
    return { ok: true, hhVacancyId: hhVacancyId ?? undefined, externalUrl: externalUrl ?? undefined };
  } catch (err) {
    const message = describeHhPublishError(err);
    console.error(`[hh_vacancies] publish failed for ${localVacancyId}:`, message);
    return { ok: false, error: message };
  }
}

/** Turn an hh.ru validation error body into a human-readable Russian message. */
function describeHhPublishError(err: unknown): string {
  if (err instanceof HhApiError) {
    try {
      const body = JSON.parse(err.body);
      const errs: any[] = body?.errors ?? [];
      if (errs.length) {
        const parts = errs.map((e) => {
          const field = e?.location ?? e?.field ?? e?.type ?? "поле";
          const reason = e?.reason ?? e?.value ?? e?.type ?? "ошибка";
          return `${field}: ${reason}`;
        });
        return `hh.ru отклонил публикацию (${err.status}): ${parts.join("; ")}`;
      }
      if (body?.description) return `hh.ru: ${body.description} (${err.status})`;
    } catch {
      /* not JSON */
    }
    return `hh.ru вернул ошибку ${err.status}: ${err.body.slice(0, 300)}`;
  }
  return err instanceof Error ? err.message : String(err);
}
