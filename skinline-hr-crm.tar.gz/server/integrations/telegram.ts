// Telegram Bot HTTP API client (no external libraries, pure fetch)

const TG_API_BASE = "https://api.telegram.org";

export function telegramConfigured(): boolean {
  return Boolean(process.env.TELEGRAM_BOT_TOKEN);
}

export function getBotUsername(): string {
  return process.env.TELEGRAM_BOT_USERNAME ?? "skinline_recruitment_bot";
}

export class TelegramClient {
  private base: string;

  constructor(private token: string) {
    this.base = `${TG_API_BASE}/bot${token}`;
  }

  async sendMessage(
    chatId: string,
    text: string,
    opts?: { parse_mode?: "HTML" | "Markdown"; reply_markup?: unknown },
  ): Promise<{ ok: boolean; message_id?: number }> {
    try {
      const body: Record<string, unknown> = { chat_id: chatId, text };
      if (opts?.parse_mode) body.parse_mode = opts.parse_mode;
      if (opts?.reply_markup) body.reply_markup = opts.reply_markup;

      const res = await fetch(`${this.base}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const json = (await res.json()) as { ok: boolean; result?: { message_id: number } };
      if (!json.ok) {
        console.warn("[telegram] sendMessage failed:", JSON.stringify(json));
      }
      return { ok: json.ok, message_id: json.result?.message_id };
    } catch (err) {
      console.error("[telegram] sendMessage error:", err);
      return { ok: false };
    }
  }

  async getMe(): Promise<{ username: string; id: number }> {
    const res = await fetch(`${this.base}/getMe`);
    const json = (await res.json()) as { ok: boolean; result?: { username: string; id: number } };
    if (!json.ok || !json.result) throw new Error("Telegram getMe failed");
    return json.result;
  }

  async setWebhook(url: string): Promise<void> {
    const res = await fetch(`${this.base}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const json = (await res.json()) as { ok: boolean; description?: string };
    if (!json.ok) throw new Error(`setWebhook failed: ${json.description ?? "unknown"}`);
  }
}

let _instance: TelegramClient | null = null;

export function getTelegram(): TelegramClient | null {
  if (!telegramConfigured()) return null;
  if (!_instance) {
    _instance = new TelegramClient(process.env.TELEGRAM_BOT_TOKEN!);
  }
  return _instance;
}
