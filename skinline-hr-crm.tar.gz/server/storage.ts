import {
  vacancies, candidates, documents, messages, activities,
  integrations, externalRefs, oauthStates, webhookEvents,
  crmUsers, tasks, scheduledActions, stageEvents, telegramLinks,
} from '@shared/schema';
import type {
  Vacancy, InsertVacancy,
  Candidate, InsertCandidate,
  Document, InsertDocument,
  Message, InsertMessage,
  Activity, InsertActivity,
  Integration, InsertIntegration,
  ExternalRef, InsertExternalRef,
  OauthState,
  WebhookEvent, InsertWebhookEvent,
  CrmUser, InsertCrmUser,
  Task, InsertTask,
  ScheduledAction, InsertScheduledAction,
  StageEvent, InsertStageEvent,
  TelegramLink,
} from '@shared/schema';
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc, and, lt, lte } from "drizzle-orm";
import { randomUUID } from "node:crypto";

const sqlite = new Database("data.db");
sqlite.pragma("journal_mode = WAL");

// Create tables if not present (template ships without migrations for our schema)
sqlite.exec(`
CREATE TABLE IF NOT EXISTS vacancies (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, city TEXT NOT NULL,
  salary TEXT NOT NULL, status TEXT NOT NULL, description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS candidates (
  id TEXT PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT,
  city TEXT NOT NULL, vacancy_id TEXT NOT NULL, source TEXT NOT NULL, source_url TEXT,
  stage TEXT NOT NULL, experience TEXT NOT NULL, expected_salary TEXT, rating INTEGER,
  notes TEXT, tags TEXT NOT NULL DEFAULT '[]', reject_reason TEXT, avatar_url TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, type TEXT NOT NULL,
  file_name TEXT NOT NULL, file_url TEXT NOT NULL, uploaded_at TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, channel TEXT NOT NULL,
  direction TEXT NOT NULL, text TEXT NOT NULL, sent_at TEXT NOT NULL,
  is_read INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS activities (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, type TEXT NOT NULL,
  description TEXT NOT NULL, created_at TEXT NOT NULL, meta TEXT
);
CREATE TABLE IF NOT EXISTS integrations (
  id TEXT PRIMARY KEY, source TEXT NOT NULL, status TEXT NOT NULL,
  account_id TEXT, account_name TEXT, access_token TEXT, refresh_token TEXT,
  token_expires_at TEXT, last_sync_at TEXT, last_error TEXT, meta TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS external_refs (
  id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
  source TEXT NOT NULL, external_id TEXT NOT NULL, external_type TEXT NOT NULL,
  meta TEXT, created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_external_refs_unique
  ON external_refs (source, external_type, external_id);
CREATE TABLE IF NOT EXISTS oauth_states (
  state TEXT PRIMARY KEY, source TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS webhook_events (
  id TEXT PRIMARY KEY, source TEXT NOT NULL, event_type TEXT NOT NULL,
  external_id TEXT, payload TEXT NOT NULL, status TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT,
  received_at TEXT NOT NULL, processed_at TEXT
);
CREATE TABLE IF NOT EXISTS crm_users (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, role_key TEXT NOT NULL,
  telegram_username TEXT, telegram_chat_id TEXT, email TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, assignee_id TEXT NOT NULL,
  title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', due_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL,
  completed_at TEXT, source TEXT NOT NULL DEFAULT 'manual', trigger_stage TEXT
);
CREATE TABLE IF NOT EXISTS scheduled_actions (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL,
  kind TEXT NOT NULL, run_at TEXT NOT NULL, payload TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', trigger_stage TEXT NOT NULL,
  created_at TEXT NOT NULL, executed_at TEXT, last_error TEXT
);
CREATE TABLE IF NOT EXISTS stage_events (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL,
  from_stage TEXT, to_stage TEXT NOT NULL,
  changed_by TEXT NOT NULL, changed_at TEXT NOT NULL, meta TEXT
);
CREATE TABLE IF NOT EXISTS telegram_links (
  candidate_id TEXT PRIMARY KEY, chat_id TEXT NOT NULL,
  username TEXT, linked_at TEXT NOT NULL, bot_username TEXT NOT NULL
);
`);

// Lightweight migrations for columns added to pre-existing tables.
function ensureColumn(table: string, column: string, ddl: string) {
  const cols = sqlite.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (!cols.some((c) => c.name === column)) {
    sqlite.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  }
}
ensureColumn("candidates", "resume_url", "resume_url TEXT");
ensureColumn("candidates", "external_avatar_url", "external_avatar_url TEXT");
ensureColumn("candidates", "telegram_chat_id", "telegram_chat_id TEXT");
ensureColumn("candidates", "link_token", "link_token TEXT");
ensureColumn("candidates", "last_stage_at", "last_stage_at TEXT");
ensureColumn("vacancies", "external_url", "external_url TEXT");
ensureColumn("messages", "source", "source TEXT");
ensureColumn("messages", "external_id", "external_id TEXT");
ensureColumn("messages", "delivery_status", "delivery_status TEXT");
ensureColumn("messages", "meta", "meta TEXT");

export const db = drizzle(sqlite);

export interface IStorage {
  // vacancies
  getVacancies(): Promise<Vacancy[]>;
  getVacancy(id: string): Promise<Vacancy | undefined>;
  createVacancy(v: InsertVacancy): Promise<Vacancy>;
  updateVacancy(id: string, v: Partial<InsertVacancy>): Promise<Vacancy | undefined>;
  deleteVacancy(id: string): Promise<void>;
  // candidates
  getCandidates(filters?: { stage?: string; vacancyId?: string; source?: string }): Promise<Candidate[]>;
  getCandidate(id: string): Promise<Candidate | undefined>;
  getCandidateByPhone(phone: string): Promise<Candidate | undefined>;
  getCandidateByLinkToken(token: string): Promise<Candidate | undefined>;
  getCandidateByTelegramChatId(chatId: string): Promise<Candidate | undefined>;
  createCandidate(c: InsertCandidate): Promise<Candidate>;
  updateCandidate(id: string, c: Partial<InsertCandidate>): Promise<Candidate | undefined>;
  deleteCandidate(id: string): Promise<void>;
  // documents
  getDocuments(candidateId: string): Promise<Document[]>;
  createDocument(d: InsertDocument): Promise<Document>;
  updateDocument(id: string, d: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: string): Promise<void>;
  // messages
  getMessages(candidateId: string): Promise<Message[]>;
  createMessage(m: InsertMessage): Promise<Message>;
  createMessageAt(m: InsertMessage, sentAt: string): Promise<Message>;
  getMessage(id: string): Promise<Message | undefined>;
  getMessageByExternal(source: string, externalId: string): Promise<Message | undefined>;
  updateMessage(id: string, m: Partial<Message>): Promise<Message | undefined>;
  // activities
  getActivities(candidateId: string): Promise<Activity[]>;
  createActivity(a: InsertActivity): Promise<Activity>;
  getRecentActivities(limit: number): Promise<Activity[]>;
  // integrations
  getIntegrations(): Promise<Integration[]>;
  getIntegration(source: string): Promise<Integration | undefined>;
  getIntegrationsByStatus(status: string): Promise<Integration[]>;
  upsertIntegration(source: string, data: Partial<InsertIntegration>): Promise<Integration>;
  updateIntegration(id: string, data: Partial<Integration>): Promise<Integration | undefined>;
  // external refs
  getExternalRef(source: string, externalType: string, externalId: string): Promise<ExternalRef | undefined>;
  getExternalRefsForEntity(entityType: string, entityId: string): Promise<ExternalRef[]>;
  getExternalRefByEntity(entityType: string, entityId: string, source: string, externalType: string): Promise<ExternalRef | undefined>;
  createExternalRef(r: InsertExternalRef): Promise<ExternalRef>;
  // oauth states
  createOauthState(state: string, source: string): Promise<OauthState>;
  getOauthState(state: string): Promise<OauthState | undefined>;
  deleteOauthState(state: string): Promise<void>;
  deleteExpiredOauthStates(beforeIso: string): Promise<number>;
  // webhook events
  createWebhookEvent(e: InsertWebhookEvent): Promise<WebhookEvent>;
  getWebhookEvent(id: string): Promise<WebhookEvent | undefined>;
  getPendingWebhookEvents(limit: number): Promise<WebhookEvent[]>;
  updateWebhookEvent(id: string, data: Partial<WebhookEvent>): Promise<WebhookEvent | undefined>;
  // crm_users
  getCrmUsers(): Promise<CrmUser[]>;
  getCrmUser(id: string): Promise<CrmUser | undefined>;
  getCrmUserByRole(roleKey: string): Promise<CrmUser | undefined>;
  upsertCrmUser(user: InsertCrmUser): Promise<CrmUser>;
  updateCrmUser(id: string, data: Partial<CrmUser>): Promise<CrmUser | undefined>;
  // tasks
  getTasks(candidateId: string): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  createTask(t: InsertTask): Promise<Task>;
  updateTask(id: string, data: Partial<Task>): Promise<Task | undefined>;
  // scheduled_actions
  getScheduledActions(candidateId: string): Promise<ScheduledAction[]>;
  getPendingScheduledActions(beforeOrAt: string): Promise<ScheduledAction[]>;
  createScheduledAction(a: InsertScheduledAction): Promise<ScheduledAction>;
  updateScheduledAction(id: string, data: Partial<ScheduledAction>): Promise<ScheduledAction | undefined>;
  cancelPendingActionsForStage(candidateId: string, triggerStage: string): Promise<void>;
  // stage_events
  getStageEvents(candidateId: string): Promise<StageEvent[]>;
  createStageEvent(e: InsertStageEvent): Promise<StageEvent>;
  // telegram_links
  getTelegramLink(candidateId: string): Promise<TelegramLink | undefined>;
  upsertTelegramLink(link: TelegramLink): Promise<TelegramLink>;
}

export class DatabaseStorage implements IStorage {
  // ---- vacancies ----
  async getVacancies(): Promise<Vacancy[]> {
    return db.select().from(vacancies).all();
  }
  async getVacancy(id: string): Promise<Vacancy | undefined> {
    return db.select().from(vacancies).where(eq(vacancies.id, id)).get();
  }
  async createVacancy(v: InsertVacancy): Promise<Vacancy> {
    return db.insert(vacancies).values({ ...v, id: randomUUID() }).returning().get();
  }
  async updateVacancy(id: string, v: Partial<InsertVacancy>): Promise<Vacancy | undefined> {
    return db.update(vacancies).set(v).where(eq(vacancies.id, id)).returning().get();
  }
  async deleteVacancy(id: string): Promise<void> {
    db.delete(vacancies).where(eq(vacancies.id, id)).run();
  }

  // ---- candidates ----
  async getCandidates(filters?: { stage?: string; vacancyId?: string; source?: string }): Promise<Candidate[]> {
    let rows = db.select().from(candidates).orderBy(desc(candidates.createdAt)).all();
    if (filters?.stage) rows = rows.filter((r) => r.stage === filters.stage);
    if (filters?.vacancyId) rows = rows.filter((r) => r.vacancyId === filters.vacancyId);
    if (filters?.source) rows = rows.filter((r) => r.source === filters.source);
    return rows;
  }
  async getCandidate(id: string): Promise<Candidate | undefined> {
    return db.select().from(candidates).where(eq(candidates.id, id)).get();
  }
  async getCandidateByPhone(phone: string): Promise<Candidate | undefined> {
    return db.select().from(candidates).where(eq(candidates.phone, phone)).get();
  }
  async getCandidateByLinkToken(token: string): Promise<Candidate | undefined> {
    return db.select().from(candidates).where(eq(candidates.linkToken, token)).get();
  }
  async getCandidateByTelegramChatId(chatId: string): Promise<Candidate | undefined> {
    return db.select().from(candidates).where(eq(candidates.telegramChatId, chatId)).get();
  }
  async createCandidate(c: InsertCandidate): Promise<Candidate> {
    return db.insert(candidates).values({
      ...c, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async updateCandidate(id: string, c: Partial<InsertCandidate>): Promise<Candidate | undefined> {
    return db.update(candidates).set(c).where(eq(candidates.id, id)).returning().get();
  }
  async deleteCandidate(id: string): Promise<void> {
    db.delete(candidates).where(eq(candidates.id, id)).run();
    db.delete(messages).where(eq(messages.candidateId, id)).run();
    db.delete(documents).where(eq(documents.candidateId, id)).run();
    db.delete(activities).where(eq(activities.candidateId, id)).run();
  }

  // ---- documents ----
  async getDocuments(candidateId: string): Promise<Document[]> {
    return db.select().from(documents).where(eq(documents.candidateId, candidateId)).all();
  }
  async createDocument(d: InsertDocument): Promise<Document> {
    return db.insert(documents).values({
      ...d, id: randomUUID(), uploadedAt: new Date().toISOString(),
    }).returning().get();
  }
  async updateDocument(id: string, d: Partial<InsertDocument>): Promise<Document | undefined> {
    return db.update(documents).set(d).where(eq(documents.id, id)).returning().get();
  }
  async deleteDocument(id: string): Promise<void> {
    db.delete(documents).where(eq(documents.id, id)).run();
  }

  // ---- messages ----
  async getMessages(candidateId: string): Promise<Message[]> {
    return db.select().from(messages).where(eq(messages.candidateId, candidateId)).all();
  }
  async createMessage(m: InsertMessage): Promise<Message> {
    return db.insert(messages).values({
      ...m, id: randomUUID(), sentAt: new Date().toISOString(),
    }).returning().get();
  }
  async createMessageAt(m: InsertMessage, sentAt: string): Promise<Message> {
    return db.insert(messages).values({
      ...m, id: randomUUID(), sentAt,
    }).returning().get();
  }
  async getMessage(id: string): Promise<Message | undefined> {
    return db.select().from(messages).where(eq(messages.id, id)).get();
  }
  async getMessageByExternal(source: string, externalId: string): Promise<Message | undefined> {
    return db.select().from(messages)
      .where(and(eq(messages.source, source), eq(messages.externalId, externalId))).get();
  }
  async updateMessage(id: string, m: Partial<Message>): Promise<Message | undefined> {
    return db.update(messages).set(m).where(eq(messages.id, id)).returning().get();
  }

  // ---- activities ----
  async getActivities(candidateId: string): Promise<Activity[]> {
    return db.select().from(activities).where(eq(activities.candidateId, candidateId))
      .orderBy(desc(activities.createdAt)).all();
  }
  async createActivity(a: InsertActivity): Promise<Activity> {
    return db.insert(activities).values({
      ...a, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async getRecentActivities(limit: number): Promise<Activity[]> {
    return db.select().from(activities).orderBy(desc(activities.createdAt)).limit(limit).all();
  }

  // ---- integrations ----
  async getIntegrations(): Promise<Integration[]> {
    return db.select().from(integrations).all();
  }
  async getIntegration(source: string): Promise<Integration | undefined> {
    return db.select().from(integrations).where(eq(integrations.source, source)).get();
  }
  async getIntegrationsByStatus(status: string): Promise<Integration[]> {
    return db.select().from(integrations).where(eq(integrations.status, status)).all();
  }
  async upsertIntegration(source: string, data: Partial<InsertIntegration>): Promise<Integration> {
    const now = new Date().toISOString();
    const existing = await this.getIntegration(source);
    if (existing) {
      return db.update(integrations)
        .set({ ...data, updatedAt: now })
        .where(eq(integrations.id, existing.id)).returning().get();
    }
    return db.insert(integrations).values({
      id: randomUUID(), source,
      status: data.status ?? "disconnected",
      accountId: data.accountId ?? null,
      accountName: data.accountName ?? null,
      accessToken: data.accessToken ?? null,
      refreshToken: data.refreshToken ?? null,
      tokenExpiresAt: data.tokenExpiresAt ?? null,
      lastSyncAt: data.lastSyncAt ?? null,
      lastError: data.lastError ?? null,
      meta: data.meta ?? null,
      createdAt: now, updatedAt: now,
    }).returning().get();
  }
  async updateIntegration(id: string, data: Partial<Integration>): Promise<Integration | undefined> {
    return db.update(integrations)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(integrations.id, id)).returning().get();
  }

  // ---- external refs ----
  async getExternalRef(source: string, externalType: string, externalId: string): Promise<ExternalRef | undefined> {
    return db.select().from(externalRefs).where(and(
      eq(externalRefs.source, source),
      eq(externalRefs.externalType, externalType),
      eq(externalRefs.externalId, externalId),
    )).get();
  }
  async getExternalRefsForEntity(entityType: string, entityId: string): Promise<ExternalRef[]> {
    return db.select().from(externalRefs).where(and(
      eq(externalRefs.entityType, entityType),
      eq(externalRefs.entityId, entityId),
    )).all();
  }
  async getExternalRefByEntity(entityType: string, entityId: string, source: string, externalType: string): Promise<ExternalRef | undefined> {
    return db.select().from(externalRefs).where(and(
      eq(externalRefs.entityType, entityType),
      eq(externalRefs.entityId, entityId),
      eq(externalRefs.source, source),
      eq(externalRefs.externalType, externalType),
    )).get();
  }
  async createExternalRef(r: InsertExternalRef): Promise<ExternalRef> {
    return db.insert(externalRefs).values({
      ...r, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }

  // ---- oauth states ----
  async createOauthState(state: string, source: string): Promise<OauthState> {
    return db.insert(oauthStates).values({
      state, source, createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async getOauthState(state: string): Promise<OauthState | undefined> {
    return db.select().from(oauthStates).where(eq(oauthStates.state, state)).get();
  }
  async deleteOauthState(state: string): Promise<void> {
    db.delete(oauthStates).where(eq(oauthStates.state, state)).run();
  }
  async deleteExpiredOauthStates(beforeIso: string): Promise<number> {
    const res = db.delete(oauthStates).where(lt(oauthStates.createdAt, beforeIso)).run();
    return res.changes;
  }

  // ---- webhook events ----
  async createWebhookEvent(e: InsertWebhookEvent): Promise<WebhookEvent> {
    return db.insert(webhookEvents).values({
      ...e, id: randomUUID(), receivedAt: new Date().toISOString(),
    }).returning().get();
  }
  async getWebhookEvent(id: string): Promise<WebhookEvent | undefined> {
    return db.select().from(webhookEvents).where(eq(webhookEvents.id, id)).get();
  }
  async getPendingWebhookEvents(limit: number): Promise<WebhookEvent[]> {
    return db.select().from(webhookEvents)
      .where(eq(webhookEvents.status, "pending"))
      .orderBy(webhookEvents.receivedAt).limit(limit).all();
  }
  async updateWebhookEvent(id: string, data: Partial<WebhookEvent>): Promise<WebhookEvent | undefined> {
    return db.update(webhookEvents).set(data).where(eq(webhookEvents.id, id)).returning().get();
  }

  // ---- crm_users ----
  async getCrmUsers(): Promise<CrmUser[]> {
    return db.select().from(crmUsers).all();
  }
  async getCrmUser(id: string): Promise<CrmUser | undefined> {
    return db.select().from(crmUsers).where(eq(crmUsers.id, id)).get();
  }
  async getCrmUserByRole(roleKey: string): Promise<CrmUser | undefined> {
    return db.select().from(crmUsers).where(eq(crmUsers.roleKey, roleKey)).get();
  }
  async upsertCrmUser(user: InsertCrmUser): Promise<CrmUser> {
    const existing = await this.getCrmUser(user.id);
    if (existing) {
      return db.update(crmUsers).set(user).where(eq(crmUsers.id, user.id)).returning().get();
    }
    return db.insert(crmUsers).values({
      ...user, createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async updateCrmUser(id: string, data: Partial<CrmUser>): Promise<CrmUser | undefined> {
    return db.update(crmUsers).set(data).where(eq(crmUsers.id, id)).returning().get();
  }

  // ---- tasks ----
  async getTasks(candidateId: string): Promise<Task[]> {
    return db.select().from(tasks).where(eq(tasks.candidateId, candidateId))
      .orderBy(desc(tasks.createdAt)).all();
  }
  async getTask(id: string): Promise<Task | undefined> {
    return db.select().from(tasks).where(eq(tasks.id, id)).get();
  }
  async createTask(t: InsertTask): Promise<Task> {
    return db.insert(tasks).values({
      ...t, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async updateTask(id: string, data: Partial<Task>): Promise<Task | undefined> {
    return db.update(tasks).set(data).where(eq(tasks.id, id)).returning().get();
  }

  // ---- scheduled_actions ----
  async getScheduledActions(candidateId: string): Promise<ScheduledAction[]> {
    return db.select().from(scheduledActions).where(eq(scheduledActions.candidateId, candidateId))
      .orderBy(scheduledActions.runAt).all();
  }
  async getPendingScheduledActions(beforeOrAt: string): Promise<ScheduledAction[]> {
    return db.select().from(scheduledActions).where(
      and(
        eq(scheduledActions.status, "pending"),
        lte(scheduledActions.runAt, beforeOrAt),
      )
    ).all();
  }
  async createScheduledAction(a: InsertScheduledAction): Promise<ScheduledAction> {
    return db.insert(scheduledActions).values({
      ...a, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async updateScheduledAction(id: string, data: Partial<ScheduledAction>): Promise<ScheduledAction | undefined> {
    return db.update(scheduledActions).set(data).where(eq(scheduledActions.id, id)).returning().get();
  }
  async cancelPendingActionsForStage(candidateId: string, triggerStage: string): Promise<void> {
    db.update(scheduledActions)
      .set({ status: "cancelled" })
      .where(and(
        eq(scheduledActions.candidateId, candidateId),
        eq(scheduledActions.triggerStage, triggerStage),
        eq(scheduledActions.status, "pending"),
      )).run();
  }

  // ---- stage_events ----
  async getStageEvents(candidateId: string): Promise<StageEvent[]> {
    return db.select().from(stageEvents).where(eq(stageEvents.candidateId, candidateId))
      .orderBy(desc(stageEvents.changedAt)).all();
  }
  async createStageEvent(e: InsertStageEvent): Promise<StageEvent> {
    return db.insert(stageEvents).values({
      ...e, id: randomUUID(),
    }).returning().get();
  }

  // ---- telegram_links ----
  async getTelegramLink(candidateId: string): Promise<TelegramLink | undefined> {
    return db.select().from(telegramLinks).where(eq(telegramLinks.candidateId, candidateId)).get();
  }
  async upsertTelegramLink(link: TelegramLink): Promise<TelegramLink> {
    const existing = await this.getTelegramLink(link.candidateId);
    if (existing) {
      return db.update(telegramLinks).set(link).where(eq(telegramLinks.candidateId, link.candidateId)).returning().get();
    }
    return db.insert(telegramLinks).values(link).returning().get();
  }
}

export const storage = new DatabaseStorage();

// ============ SEED ============
function iso(daysAgo: number, hour = 10, min = 0): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, min, 0, 0);
  return d.toISOString();
}

export function seedDatabase() {
  const existing = db.select().from(vacancies).all();
  if (existing.length > 0) return;

  // ---- CRM Users (7 rows) ----
  const crmUserDefs: Array<{ id: string; name: string; roleKey: string; telegramUsername: string | null; telegramChatId: string | null; email: string | null }> = [
    { id: "u_hr", name: "HR-менеджер", roleKey: "hr_manager", telegramUsername: "HR_SKIN_LINE", telegramChatId: null, email: null },
    { id: "u_uk", name: "Дарья (Сотрудник УК)", roleKey: "uk", telegramUsername: "daryaalexandrovna98", telegramChatId: null, email: null },
    { id: "u_t1", name: "Махпура (Тренер 1)", roleKey: "trainer_1", telegramUsername: "dr_Abdullaeva_Mahpura", telegramChatId: null, email: null },
    { id: "u_t2", name: "Виктория (Тренер 2)", roleKey: "trainer_2", telegramUsername: "Viktoriya_vi_a", telegramChatId: null, email: null },
    { id: "u_mgr", name: "Управляющая", roleKey: "manager", telegramUsername: "VictoriaShkeneva", telegramChatId: null, email: null },
    { id: "u_dina", name: "Дина", roleKey: "ops", telegramUsername: null, telegramChatId: null, email: null },
    { id: "u_tamara", name: "Тамара", roleKey: "ops", telegramUsername: null, telegramChatId: null, email: null },
  ];
  const now = new Date().toISOString();
  for (const u of crmUserDefs) {
    db.insert(crmUsers).values({ ...u, createdAt: now }).run();
  }

  // ---- Vacancies (5) ----
  const vacancyDefs = [
    { id: randomUUID(), title: "Мастер лазерной эпиляции", city: "Чебоксары", salary: "от 80 000 ₽", status: "active", description: "Мастер лазерной эпиляции в сеть студий Skin Line. График 2/2, обучение от компании.", externalUrl: null },
    { id: randomUUID(), title: "Мастер лазерной эпиляции", city: "Йошкар-Ола", salary: "от 75 000 ₽", status: "active", description: "Мастер лазерной эпиляции в Skin Line. Стабильный доход, клиентская база.", externalUrl: null },
    { id: randomUUID(), title: "Мастер лазерной эпиляции", city: "Казань", salary: "от 90 000 ₽", status: "active", description: "Мастер лазерной эпиляции в студию Skin Line в Казани. Опыт приветствуется.", externalUrl: null },
    { id: randomUUID(), title: "Мастер лазерной эпиляции", city: "Воронеж", salary: "от 70 000 ₽", status: "active", description: "Приглашаем мастера лазерной эпиляции в Skin Line Воронеж.", externalUrl: null },
    { id: randomUUID(), title: "Мастер лазерной эпиляции", city: "Киров", salary: "от 72 000 ₽", status: "paused", description: "Мастер лазерной эпиляции в студию Skin Line. Обучение за счёт компании.", externalUrl: null },
  ];
  db.insert(vacancies).values(vacancyDefs).run();
  const [vCheb, vYosh, vKaz, vVor, vKir] = vacancyDefs;

  const CITIES_SKIN_LINE = [
    "Чебоксары", "Йошкар-Ола", "Казань", "Воронеж", "Липецк",
    "Киров", "Курск", "Набережные Челны", "Новочебоксарск", "Сургут",
  ];

  type SeedC = {
    name: string; phone: string; email: string | null; city: string; vacancy: typeof vacancyDefs[0];
    source: string; stage: string; exp: string; expected: string | null; tags: string[];
  };

  // 15 candidates distributed across 14 stages per spec
  const seeds: SeedC[] = [
    // form_filled: 3
    { name: "Анна Иванова", phone: "+7 916 123-45-67", email: "anna@mail.ru", city: "Чебоксары", vacancy: vCheb, source: "avito", stage: "form_filled", exp: "1 год", expected: null, tags: ["Чебоксары"] },
    { name: "Екатерина Петрова", phone: "+7 921 234-56-78", email: null, city: "Йошкар-Ола", vacancy: vYosh, source: "hh", stage: "form_filled", exp: "без опыта", expected: null, tags: ["Йошкар-Ола"] },
    { name: "Мария Соколова", phone: "+7 917 345-67-89", email: "m.s@gmail.com", city: "Казань", vacancy: vKaz, source: "manual", stage: "form_filled", exp: "2 года", expected: null, tags: ["Казань"] },
    // in_work: 2
    { name: "Ольга Кузнецова", phone: "+7 905 456-78-90", email: null, city: "Воронеж", vacancy: vVor, source: "avito", stage: "in_work", exp: "3 года", expected: "75 000 ₽", tags: ["Воронеж"] },
    { name: "Наталья Морозова", phone: "+7 926 567-89-01", email: "nat@ya.ru", city: "Липецк", vacancy: vCheb, source: "hh", stage: "in_work", exp: "1 год", expected: null, tags: ["Липецк"] },
    // video_interview: 2
    { name: "Юлия Васильева", phone: "+7 903 678-90-12", email: null, city: "Киров", vacancy: vKir, source: "avito", stage: "video_interview", exp: "2 года", expected: "70 000 ₽", tags: ["Киров"] },
    { name: "Светлана Орлова", phone: "+7 911 789-01-23", email: "sv@mail.ru", city: "Курск", vacancy: vVor, source: "hh", stage: "video_interview", exp: "4 года", expected: "80 000 ₽", tags: ["Курск"] },
    // studio_demo: 1
    { name: "Дарья Никитина", phone: "+7 918 890-12-34", email: null, city: "Набережные Челны", vacancy: vKaz, source: "manual", stage: "studio_demo", exp: "3 года", expected: "85 000 ₽", tags: ["Набережные Челны"] },
    // theory: 2
    { name: "Алина Смирнова", phone: "+7 902 901-23-45", email: "alina@gmail.com", city: "Новочебоксарск", vacancy: vCheb, source: "avito", stage: "theory", exp: "1 год", expected: null, tags: ["Новочебоксарск"] },
    { name: "Виктория Лебедева", phone: "+7 925 012-34-56", email: null, city: "Сургут", vacancy: vYosh, source: "hh", stage: "theory", exp: "2 года", expected: "90 000 ₽", tags: ["Сургут"] },
    // exam_scheduled: 1
    { name: "Татьяна Зайцева", phone: "+7 909 123-45-67", email: "t.z@mail.ru", city: "Чебоксары", vacancy: vCheb, source: "avito", stage: "exam_scheduled", exp: "3 года", expected: "80 000 ₽", tags: ["Чебоксары"] },
    // reexam: 1
    { name: "Елена Попова", phone: "+7 916 234-56-78", email: null, city: "Йошкар-Ола", vacancy: vYosh, source: "hh", stage: "reexam", exp: "2 года", expected: null, tags: ["Йошкар-Ола"] },
    // trainer_onboarding: 1
    { name: "Кристина Волкова", phone: "+7 921 345-67-89", email: "k.v@ya.ru", city: "Казань", vacancy: vKaz, source: "manual", stage: "trainer_onboarding", exp: "5 лет", expected: "95 000 ₽", tags: ["Казань"] },
    // scheduled: 1
    { name: "Полина Соловьёва", phone: "+7 917 456-78-90", email: null, city: "Воронеж", vacancy: vVor, source: "avito", stage: "scheduled", exp: "4 года", expected: "85 000 ₽", tags: ["Воронеж"] },
    // rejected: 1
    { name: "Алёна Козлова", phone: "+7 905 567-89-01", email: null, city: "Чебоксары", vacancy: vCheb, source: "avito", stage: "rejected", exp: "без опыта", expected: null, tags: ["Чебоксары"] },
  ];

  const msgInbound = [
    "Здравствуйте! Видела вашу вакансию, очень заинтересована.",
    "Подскажите, какой график работы и условия?",
    "Да, у меня есть сертификаты.",
    "Удобно созвониться завтра после 15:00?",
    "Спасибо за информацию, жду приглашение на собеседование.",
    "Готова приехать на демо-погружение в любой день.",
  ];
  const msgOutbound = [
    "Добрый день! Спасибо за отклик. Расскажите о вашем опыте?",
    "Обучение проводится за счёт компании, график 2/2.",
    "Отлично! Приглашаем вас на онлайн-собеседование.",
    "Можете заполнить анкету по ссылке?",
    "Записали вас на демо-погружение, ждём!",
    "Хорошего дня! Будем на связи.",
  ];

  let dayCounter = 0;
  for (const s of seeds) {
    dayCounter += 1;
    const created = iso(20 - dayCounter % 18, 9 + (dayCounter % 6));
    const cand = db.insert(candidates).values({
      id: randomUUID(),
      fullName: s.name,
      phone: s.phone,
      email: s.email,
      city: s.city,
      vacancyId: s.vacancy.id,
      source: s.source,
      sourceUrl: s.source === "avito" ? "https://www.avito.ru/moskva/rezume/master" :
                 s.source === "hh" ? "https://hh.ru/resume/example" : null,
      stage: s.stage,
      experience: s.exp,
      expectedSalary: s.expected,
      rating: null,
      notes: null,
      tags: JSON.stringify(s.tags),
      rejectReason: null,
      avatarUrl: null,
      createdAt: created,
      telegramChatId: null,
      linkToken: null,
      lastStageAt: created,
    }).returning().get();

    // messages: 2-5
    const nMsgs = 2 + (dayCounter % 4);
    for (let i = 0; i < nMsgs; i++) {
      const outbound = i % 2 === 1;
      db.insert(messages).values({
        id: randomUUID(),
        candidateId: cand.id,
        channel: "telegram",
        direction: outbound ? "out" : "in",
        text: outbound ? msgOutbound[i % msgOutbound.length] : msgInbound[i % msgInbound.length],
        sentAt: iso(15 - dayCounter % 12, 10 + i, i * 7 % 60),
        isRead: 1,
      }).run();
    }

    // activities: 1-3
    db.insert(activities).values({
      id: randomUUID(), candidateId: cand.id, type: "stage_change",
      description: `Кандидат добавлен из источника ${s.source === "avito" ? "Avito" : s.source === "hh" ? "hh.ru" : "вручную"}`,
      createdAt: created, meta: null,
    }).run();
  }

  console.log("[seed] Database seeded: 5 vacancies, 15 candidates, 7 crm_users.");
}
