// Automation engine: onStageChange triggers messages, tasks, and timers.

import { storage } from "../storage";
import { getTelegram, getBotUsername } from "../integrations/telegram";
import { randomBytes } from "node:crypto";
import {
  renderTemplate,
  TPL_FORM_FILLED_CANDIDATE,
  TPL_IN_WORK_CANDIDATE,
  TPL_VIDEO_INTERVIEW_REMINDER,
  TPL_STUDIO_DEMO_CANDIDATE,
  TPL_STUDIO_DEMO_UK,
  TPL_THEORY_CANDIDATE,
  TPL_THEORY_FOLLOWUP_CANDIDATE,
  TPL_THEORY_ESCALATION_UK,
  TPL_EXAM_SCHEDULED_CANDIDATE,
  TPL_EXAM_SCHEDULED_TRAINER1,
  TPL_EXAM_REMINDER,
  TPL_REEXAM_CANDIDATE,
  TPL_REEXAM_FOLLOWUP_CANDIDATE,
  TPL_REEXAM_ESCALATION_UK,
  TPL_TRAINER_ONBOARDING_CANDIDATE,
  TPL_TRAINER_ONBOARDING_TRAINER2,
  TPL_STUDIO_PRACTICE_UK,
  TPL_STUDIO_PRACTICE_CANDIDATE,
  TPL_SCHEDULED_CANDIDATE,
  TPL_RESERVE_CANDIDATE,
  TPL_REJECTED_CANDIDATE,
  TPL_OFFICIAL_CANDIDATE,
} from "./templates";
import type { Candidate, CrmUser } from "@shared/schema";

const BASE_URL = process.env.APP_BASE_URL ?? "https://app.skinline-hr.ru";

function candidateCardUrl(id: string): string {
  return `${BASE_URL}/candidates/${id}`;
}

function nowPlus(ms: number): string {
  return new Date(Date.now() + ms).toISOString();
}

const H1 = 60 * 60 * 1000;
const H2 = 2 * H1;
const H5 = 5 * H1;
const H24 = 24 * H1;
const H72 = 72 * H1;
const H96 = 96 * H1; // 72+24

/** Send a Telegram message to a candidate. If no chatId — record in messages only. */
async function sendToCandidateOrLog(
  candidate: Candidate,
  text: string,
  channel = "telegram_bot",
): Promise<void> {
  const sentAt = new Date().toISOString();
  try {
    const tg = getTelegram();
    if (tg && candidate.telegramChatId) {
      const result = await tg.sendMessage(candidate.telegramChatId, text);
      await storage.createMessageAt({
        candidateId: candidate.id,
        channel,
        direction: "out",
        text,
        isRead: 1,
        deliveryStatus: result.ok ? "delivered" : "failed",
        meta: result.message_id ? JSON.stringify({ tg_message_id: result.message_id }) : null,
      }, sentAt);
    } else {
      // dry-run: log it but no real send
      if (!getTelegram()) {
        console.log(`[telegram:dry-run] → candidate ${candidate.id}: ${text.substring(0, 80)}...`);
      }
      await storage.createMessageAt({
        candidateId: candidate.id,
        channel,
        direction: "out",
        text,
        isRead: 1,
        deliveryStatus: "pending",
        meta: null,
      }, sentAt);
    }
  } catch (err) {
    console.error("[engine] sendToCandidateOrLog error:", err);
  }
}

/** Send a Telegram message to a CRM user. */
async function sendToUser(user: CrmUser, text: string, candidateId: string): Promise<void> {
  const sentAt = new Date().toISOString();
  try {
    const tg = getTelegram();
    if (tg && user.telegramChatId) {
      await tg.sendMessage(user.telegramChatId, text);
    } else if (!getTelegram()) {
      console.log(`[telegram:dry-run] → user ${user.id} (${user.roleKey}): ${text.substring(0, 80)}...`);
    }
    // Record as activity on the candidate
    await storage.createActivity({
      candidateId,
      type: "message",
      description: `Уведомление отправлено ${user.name} (${user.roleKey})`,
      meta: JSON.stringify({ userId: user.id, channel: "telegram" }),
    });
  } catch (err) {
    console.error("[engine] sendToUser error:", err);
  }
}

/** Schedule a tg_message action to candidate */
async function scheduleTgMessage(candidateId: string, triggerStage: string, runAt: string, text: string): Promise<void> {
  await storage.createScheduledAction({
    candidateId,
    kind: "tg_message",
    runAt,
    payload: JSON.stringify({ text }),
    status: "pending",
    triggerStage,
  });
}

/** Schedule a tg_message_to_user action */
async function scheduleTgMessageToUser(
  candidateId: string,
  triggerStage: string,
  runAt: string,
  roleKey: string,
  text: string,
): Promise<void> {
  await storage.createScheduledAction({
    candidateId,
    kind: "tg_message_to_user",
    runAt,
    payload: JSON.stringify({ roleKey, text }),
    status: "pending",
    triggerStage,
  });
}

/** Build template vars for a candidate */
function buildVars(c: Candidate): Record<string, string> {
  return {
    name: c.fullName.split(" ")[0] ?? c.fullName,
    candidate_full_name: c.fullName,
    city: c.city,
    datetime: "{{datetime}}", // filled externally when scheduled_at is known
    trainer_name: "Махпура",
    trainer_phone: "+7 (xxx) xxx-xx-xx",
    trainer_telegram: "@dr_Abdullaeva_Mahpura",
    zoom_slot_url: "https://calendly.com/skinline-hr",
    learning_platform_url: "https://learn.skinline.ru",
    requisites_form_url: "https://forms.skinline.ru/requisites",
    candidate_card_url: candidateCardUrl(c.id),
  };
}

// ─────────────────────────────────────────────────────────────
// Main onStageChange handler
// ─────────────────────────────────────────────────────────────

export async function onStageChange(
  candidate: Candidate,
  fromStage: string | null,
  toStage: string,
  actor: string,
): Promise<void> {
  try {
    const now = new Date().toISOString();

    // 1. Record stage event
    await storage.createStageEvent({
      candidateId: candidate.id,
      fromStage: fromStage ?? null,
      toStage,
      changedBy: actor,
      changedAt: now,
      meta: null,
    });

    // 2. Create activity
    await storage.createActivity({
      candidateId: candidate.id,
      type: "stage_change",
      description: `Стадия изменена: ${fromStage ?? "—"} → ${toStage}`,
      meta: JSON.stringify({ fromStage, toStage, actor }),
    });

    // 3. Cancel pending actions from the previous stage
    if (fromStage) {
      await storage.cancelPendingActionsForStage(candidate.id, fromStage);
    }

    // 4. Update last_stage_at
    await storage.updateCandidate(candidate.id, { lastStageAt: now });

    const vars = buildVars(candidate);

    // 5. Stage-specific automations
    switch (toStage) {

      case "form_filled": {
        // Send welcome message to candidate
        const text = renderTemplate(TPL_FORM_FILLED_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);
        break;
      }

      case "in_work": {
        // Send Zoom slot link to candidate
        const text = renderTemplate(TPL_IN_WORK_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);
        break;
      }

      case "video_interview": {
        // Timer: 2h before scheduled_at (we schedule it for now+2h as a reasonable default;
        // caller should reschedule if scheduled_at is known)
        const reminderAt = nowPlus(H2);
        const text = renderTemplate(TPL_VIDEO_INTERVIEW_REMINDER, vars);
        await scheduleTgMessage(candidate.id, toStage, reminderAt, text);
        break;
      }

      case "studio_demo": {
        // Send congrats to candidate
        const text = renderTemplate(TPL_STUDIO_DEMO_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);

        // Task for u_uk with 5h deadline
        const uk = await storage.getCrmUserByRole("uk");
        if (uk) {
          const ukMsg = renderTemplate(TPL_STUDIO_DEMO_UK, vars);
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId: uk.id,
            title: `Демо-погружение: ${candidate.fullName}`,
            description: ukMsg,
            dueAt: nowPlus(H5),
            status: "open",
            source: "auto",
            triggerStage: toStage,
          });
        }
        break;
      }

      case "theory": {
        // Send theory message to candidate
        const text = renderTemplate(TPL_THEORY_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);

        // Timer 72h: follow-up to candidate
        const followup = renderTemplate(TPL_THEORY_FOLLOWUP_CANDIDATE, vars);
        await scheduleTgMessage(candidate.id, toStage, nowPlus(H72), followup);

        // Timer 72+24h: escalation to u_uk
        const escalation = renderTemplate(TPL_THEORY_ESCALATION_UK, vars);
        await scheduleTgMessageToUser(candidate.id, toStage, nowPlus(H96), "uk", escalation);
        break;
      }

      case "exam_scheduled": {
        // Send exam notification to candidate
        const candidateMsg = renderTemplate(TPL_EXAM_SCHEDULED_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, candidateMsg);

        // Send notification to trainer_1
        const trainer1 = await storage.getCrmUserByRole("trainer_1");
        if (trainer1) {
          const t1Msg = renderTemplate(TPL_EXAM_SCHEDULED_TRAINER1, vars);
          await sendToUser(trainer1, t1Msg, candidate.id);
        }

        // Timer 2h before scheduled_at → reminder to candidate
        const reminderAt = nowPlus(H2);
        const reminder = renderTemplate(TPL_EXAM_REMINDER, vars);
        await scheduleTgMessage(candidate.id, toStage, reminderAt, reminder);
        break;
      }

      case "reexam": {
        // Send reexam message to candidate
        const text = renderTemplate(TPL_REEXAM_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);

        // Timer 72h: follow-up to candidate
        const followup = renderTemplate(TPL_REEXAM_FOLLOWUP_CANDIDATE, vars);
        await scheduleTgMessage(candidate.id, toStage, nowPlus(H72), followup);

        // Timer 72+24h: escalation to u_uk
        const escalation = renderTemplate(TPL_REEXAM_ESCALATION_UK, vars);
        await scheduleTgMessageToUser(candidate.id, toStage, nowPlus(H96), "uk", escalation);
        break;
      }

      case "trainer_onboarding": {
        // Send onboarding message to candidate
        const text = renderTemplate(TPL_TRAINER_ONBOARDING_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);

        // Timer 24h: escalation to trainer_2
        const t2Msg = renderTemplate(TPL_TRAINER_ONBOARDING_TRAINER2, vars);
        await scheduleTgMessageToUser(candidate.id, toStage, nowPlus(H24), "trainer_2", t2Msg);
        break;
      }

      case "studio_practice": {
        // Send message to u_uk
        const uk = await storage.getCrmUserByRole("uk");
        if (uk) {
          const ukMsg = renderTemplate(TPL_STUDIO_PRACTICE_UK, vars);
          await sendToUser(uk, ukMsg, candidate.id);
        }
        // Send message to candidate
        const text = renderTemplate(TPL_STUDIO_PRACTICE_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);
        break;
      }

      case "scheduled": {
        // Send message to candidate
        const text = renderTemplate(TPL_SCHEDULED_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);

        // Task for u_dina: register in YCLIENTS, 24h
        const dina = await storage.getCrmUserByRole("ops");
        const dinaUser = (await storage.getCrmUsers()).find((u) => u.id === "u_dina");
        const dinaTarget = dinaUser ?? dina;
        if (dinaTarget) {
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId: dinaTarget.id,
            title: `Зарегистрировать в YCLIENTS: ${candidate.fullName}`,
            description: `Сотрудник ${candidate.fullName} (${candidateCardUrl(candidate.id)}) выходит в график, зарегистрируйте его в yclients по регламенту. Данные сотрудника в его карточке. https://docs.google.com/document/d/1k1lkYTZ1BGJdJfp2mQDej2Rf5yba2Rlmeb6GSURTiLc/edit`,
            dueAt: nowPlus(H24),
            status: "open",
            source: "auto",
            triggerStage: toStage,
          });
        }

        // Task for u_tamara: photo + info, 24h
        const tamaraUser = (await storage.getCrmUsers()).find((u) => u.id === "u_tamara");
        if (tamaraUser) {
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId: tamaraUser.id,
            title: `Фото и инфо для YCLIENTS: ${candidate.fullName}`,
            description: `Сотрудник ${candidate.fullName} (${candidateCardUrl(candidate.id)}) выходит в график, фотография и информация о сотруднике в его карточке. Зарегистрируйте его в yclients по регламенту.`,
            dueAt: nowPlus(H24),
            status: "open",
            source: "auto",
            triggerStage: toStage,
          });
        }
        break;
      }

      case "reserve": {
        // Send reserve message to candidate
        const text = renderTemplate(TPL_RESERVE_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);
        break;
      }

      case "rejected": {
        // Send rejection message to candidate
        const text = renderTemplate(TPL_REJECTED_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);
        break;
      }

      case "official": {
        // Send requisites request to candidate
        const text = renderTemplate(TPL_OFFICIAL_CANDIDATE, vars);
        await sendToCandidateOrLog(candidate, text);

        // Auto-add tag "трудоустройство"
        try {
          const currentTags: string[] = JSON.parse(candidate.tags ?? "[]");
          if (!currentTags.includes("трудоустройство")) {
            const updatedTags = [...currentTags, "трудоустройство"];
            await storage.updateCandidate(candidate.id, { tags: JSON.stringify(updatedTags) });
          }
        } catch {
          // ignore tag parse error
        }

        // Task for manager (финансовый менеджер)
        const mgr = await storage.getCrmUser("u_mgr");
        if (mgr) {
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId: mgr.id,
            title: `Связаться с бухгалтерией для оформления ${candidate.fullName}`,
            description: `Официальное трудоустройство ${candidate.fullName}. Карточка: ${candidateCardUrl(candidate.id)}`,
            dueAt: nowPlus(H24),
            status: "open",
            source: "auto",
            triggerStage: toStage,
          });
        }
        break;
      }

      case "dismissed": {
        // Task for u_dina: remove from YCLIENTS, 5h
        const dina = (await storage.getCrmUsers()).find((u) => u.id === "u_dina");
        if (dina) {
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId: dina.id,
            title: `Удалить ${candidate.fullName} из Yclients (по регламенту, не 'уволить' — именно удалить)`,
            description: `Удалить пользователя ${candidate.fullName} из Yclients по регламенту. Важно! Именно удаляем пользователя, а не опция "уволить сотрудника" из Yclients.`,
            dueAt: nowPlus(H5),
            status: "open",
            source: "auto",
            triggerStage: toStage,
          });

          // Task for u_dina: remove from chats, 5h
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId: dina.id,
            title: `Удалить ${candidate.fullName} из рабочих чатов`,
            description: `Удалить ${candidate.fullName} из всех рабочих чатов компании.`,
            dueAt: nowPlus(H5),
            status: "open",
            source: "auto",
            triggerStage: toStage,
          });
        }

        // Task for u_mgr: loyalty review request, 24h
        const mgr = await storage.getCrmUser("u_mgr");
        if (mgr) {
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId: mgr.id,
            title: `Лояльный ли сотрудник? Запросить отзыв.`,
            description: `Уволенный сотрудник ${candidate.fullName} лояльный к компании? Если да, запросить отзыв. Карточка: ${candidateCardUrl(candidate.id)}`,
            dueAt: nowPlus(H24),
            status: "open",
            source: "auto",
            triggerStage: toStage,
          });
        }
        break;
      }

      default:
        // No automations for unknown stages
        break;
    }
  } catch (err) {
    console.error("[engine] onStageChange error:", err);
    // Never crash the calling process
  }
}
