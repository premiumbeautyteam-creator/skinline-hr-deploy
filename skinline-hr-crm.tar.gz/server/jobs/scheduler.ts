// Scheduler: tick every minute, execute pending scheduled_actions

import { storage } from "../storage";
import { getTelegram } from "../integrations/telegram";
import type { ScheduledAction, Candidate, CrmUser } from "@shared/schema";

async function executeAction(action: ScheduledAction): Promise<void> {
  const candidate = await storage.getCandidate(action.candidateId);
  if (!candidate) {
    await storage.updateScheduledAction(action.id, {
      status: "cancelled",
      executedAt: new Date().toISOString(),
      lastError: "Candidate not found",
    });
    return;
  }

  // Critical check: candidate must still be on the trigger_stage
  if (candidate.stage !== action.triggerStage) {
    await storage.updateScheduledAction(action.id, {
      status: "cancelled",
      executedAt: new Date().toISOString(),
      lastError: `Stage mismatch: expected ${action.triggerStage}, got ${candidate.stage}`,
    });
    return;
  }

  const now = new Date().toISOString();

  try {
    let payload: Record<string, unknown>;
    try {
      payload = JSON.parse(action.payload) as Record<string, unknown>;
    } catch {
      payload = {};
    }

    switch (action.kind) {
      case "tg_message": {
        const text = typeof payload.text === "string" ? payload.text : "";
        await sendToCandidateOrLog(candidate, text);
        break;
      }

      case "tg_message_to_user": {
        const roleKey = typeof payload.roleKey === "string" ? payload.roleKey : "";
        const text = typeof payload.text === "string" ? payload.text : "";
        const user = await storage.getCrmUserByRole(roleKey);
        if (user) {
          await sendToUser(user, text, candidate.id);
        } else {
          console.warn(`[scheduler] User with role ${roleKey} not found for action ${action.id}`);
        }
        break;
      }

      case "create_task": {
        const assigneeId = typeof payload.assigneeId === "string" ? payload.assigneeId : "";
        const title = typeof payload.title === "string" ? payload.title : "Задача";
        const description = typeof payload.description === "string" ? payload.description : "";
        const dueOffset = typeof payload.dueOffsetMs === "number" ? payload.dueOffsetMs : 24 * 3600000;
        if (assigneeId) {
          await storage.createTask({
            candidateId: candidate.id,
            assigneeId,
            title,
            description,
            dueAt: new Date(Date.now() + dueOffset).toISOString(),
            status: "open",
            source: "auto",
            triggerStage: action.triggerStage,
          });
        }
        break;
      }

      default:
        console.warn(`[scheduler] Unknown action kind: ${action.kind}`);
        break;
    }

    await storage.updateScheduledAction(action.id, {
      status: "done",
      executedAt: now,
    });
  } catch (err) {
    console.error(`[scheduler] Action ${action.id} failed:`, err);
    await storage.updateScheduledAction(action.id, {
      status: "failed",
      executedAt: now,
      lastError: String(err),
    });
  }
}

async function sendToCandidateOrLog(candidate: Candidate, text: string): Promise<void> {
  const sentAt = new Date().toISOString();
  try {
    const tg = getTelegram();
    if (tg && candidate.telegramChatId) {
      const result = await tg.sendMessage(candidate.telegramChatId, text);
      await storage.createMessageAt({
        candidateId: candidate.id,
        channel: "telegram_bot",
        direction: "out",
        text,
        isRead: 1,
        deliveryStatus: result.ok ? "delivered" : "failed",
        meta: result.message_id ? JSON.stringify({ tg_message_id: result.message_id }) : null,
      }, sentAt);
    } else {
      if (!getTelegram()) {
        console.log(`[scheduler:dry-run] → candidate ${candidate.id}: ${text.substring(0, 80)}...`);
      }
      await storage.createMessageAt({
        candidateId: candidate.id,
        channel: "telegram_bot",
        direction: "out",
        text,
        isRead: 1,
        deliveryStatus: "pending",
        meta: null,
      }, sentAt);
    }
  } catch (err) {
    console.error("[scheduler] sendToCandidateOrLog error:", err);
  }
}

async function sendToUser(user: CrmUser, text: string, candidateId: string): Promise<void> {
  try {
    const tg = getTelegram();
    if (tg && user.telegramChatId) {
      await tg.sendMessage(user.telegramChatId, text);
    } else if (!getTelegram()) {
      console.log(`[scheduler:dry-run] → user ${user.id} (${user.roleKey}): ${text.substring(0, 80)}...`);
    }
    await storage.createActivity({
      candidateId,
      type: "message",
      description: `Таймер: уведомление отправлено ${user.name} (${user.roleKey})`,
      meta: JSON.stringify({ userId: user.id, channel: "telegram" }),
    });
  } catch (err) {
    console.error("[scheduler] sendToUser error:", err);
  }
}

let tickRunning = false;

export async function schedulerTick(): Promise<void> {
  if (tickRunning) return;
  tickRunning = true;
  try {
    const now = new Date().toISOString();
    const pending = await storage.getPendingScheduledActions(now);
    if (pending.length > 0) {
      console.log(`[scheduler] Executing ${pending.length} pending action(s)`);
    }
    for (const action of pending) {
      await executeAction(action);
    }
  } catch (err) {
    console.error("[scheduler] Tick error:", err);
  } finally {
    tickRunning = false;
  }
}

export function startScheduler(): void {
  console.log("[scheduler] Started (60s interval)");
  // Run immediately on start, then every minute
  schedulerTick().catch((err) => console.error("[scheduler] Initial tick error:", err));
  setInterval(() => {
    schedulerTick().catch((err) => console.error("[scheduler] Interval tick error:", err));
  }, 60 * 1000);
}
