import type { Express, Request } from "express";
import type { Server } from 'node:http';
import { storage, seedDatabase } from "./storage";
import {
  insertVacancySchema, insertCandidateSchema, insertDocumentSchema, insertMessageSchema,
} from "@shared/schema";
import type { Integration, IntegrationPublic } from "@shared/schema";
import { randomUUID, randomBytes } from "node:crypto";
import { HhClient, hhEnvConfigured } from "./integrations/hh";
import { pollAll, ingestNegotiation, processWebhookEvent } from "./integrations/hh-ingest";
import { AvitoClient, avitoEnvConfigured } from "./integrations/avito";
import {
  processAvitoWebhook,
  sendAvitoReply,
  pollAvitoUnread,
  type AvitoWebhookEvent,
} from "./integrations/avito-ingest";
import { encrypt } from "./lib/crypto";
import { onStageChange } from "./automations/engine";
import { getTelegram, getBotUsername } from "./integrations/telegram";
import { startScheduler } from "./jobs/scheduler";

// Strip tokens from an integration record before returning it over the API.
function maskIntegration(i: Integration): IntegrationPublic {
  const { accessToken, refreshToken, ...rest } = i;
  return { ...rest, hasTokens: Boolean(accessToken && refreshToken) };
}

// Placeholder/default integration shape for sources that have no row yet.
function placeholderIntegration(source: string): IntegrationPublic {
  const now = new Date().toISOString();
  return {
    id: "", source, status: "disconnected",
    accountId: null, accountName: null, tokenExpiresAt: null,
    lastSyncAt: null, lastError: null, meta: null,
    createdAt: now, updatedAt: now, hasTokens: false,
  };
}

const FRONTEND_SETTINGS_URL = "/#/settings";

// All 14 valid stage keys
const VALID_STAGES = new Set([
  "form_filled", "in_work", "video_interview", "studio_demo", "theory",
  "exam_scheduled", "reexam", "trainer_onboarding", "studio_practice",
  "scheduled", "reserve", "rejected", "official", "dismissed",
]);

const STAGE_LABELS: Record<string, string> = {
  form_filled: "Анкета заполнена",
  in_work: "Взяли в работу",
  video_interview: "Видеоинтервью",
  studio_demo: "Демо-погружение в студии",
  theory: "Выдаём теорию",
  exam_scheduled: "Назначен экзамен",
  reexam: "Переэкзаменовка",
  trainer_onboarding: "Обучение тренером",
  studio_practice: "Практика в студии",
  scheduled: "Выход в график",
  reserve: "Резерв",
  rejected: "Отказ",
  official: "Офиц-ое трудоустройство",
  dismissed: "Увольнение",
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  seedDatabase();
  startScheduler();

  // ---------- Vacancies ----------
  app.get("/api/vacancies", async (_req, res) => {
    res.json(await storage.getVacancies());
  });
  app.get("/api/vacancies/:id", async (req, res) => {
    const v = await storage.getVacancy(req.params.id);
    if (!v) return res.status(404).json({ message: "Вакансия не найдена" });
    res.json(v);
  });
  app.post("/api/vacancies", async (req, res) => {
    const parsed = insertVacancySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    res.status(201).json(await storage.createVacancy(parsed.data));
  });
  app.patch("/api/vacancies/:id", async (req, res) => {
    const parsed = insertVacancySchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные" });
    const v = await storage.updateVacancy(req.params.id, parsed.data);
    if (!v) return res.status(404).json({ message: "Вакансия не найдена" });
    res.json(v);
  });
  app.delete("/api/vacancies/:id", async (req, res) => {
    await storage.deleteVacancy(req.params.id);
    res.status(204).end();
  });

  // ---------- Candidates ----------
  app.get("/api/candidates", async (req, res) => {
    const { stage, vacancyId, source } = req.query as Record<string, string>;
    res.json(await storage.getCandidates({ stage, vacancyId, source }));
  });
  app.get("/api/candidates/:id", async (req, res) => {
    const c = await storage.getCandidate(req.params.id);
    if (!c) return res.status(404).json({ message: "Кандидат не найден" });
    res.json(c);
  });
  app.post("/api/candidates", async (req, res) => {
    const parsed = insertCandidateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    const c = await storage.createCandidate(parsed.data);
    await storage.createActivity({
      candidateId: c.id, type: "stage_change",
      description: "Кандидат добавлен вручную", meta: null,
    });
    // Trigger automation for initial stage
    await onStageChange(c, null, c.stage, "system");
    res.status(201).json(c);
  });
  app.patch("/api/candidates/:id", async (req, res) => {
    const parsed = insertCandidateSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные" });
    const existing = await storage.getCandidate(req.params.id);
    if (!existing) return res.status(404).json({ message: "Кандидат не найден" });

    const c = await storage.updateCandidate(req.params.id, parsed.data);
    if (!c) return res.status(404).json({ message: "Кандидат не найден" });

    // If stage changed — trigger onStageChange
    if (parsed.data.stage && parsed.data.stage !== existing.stage) {
      setImmediate(() => {
        onStageChange(c, existing.stage, c.stage, "user").catch((err) =>
          console.error("[routes] onStageChange error:", err)
        );
      });
    }
    res.json(c);
  });
  app.delete("/api/candidates/:id", async (req, res) => {
    await storage.deleteCandidate(req.params.id);
    res.status(204).end();
  });

  // stage change (dedicated endpoint)
  app.patch("/api/candidates/:id/stage", async (req, res) => {
    const { stage, rejectReason } = req.body as { stage: string; rejectReason?: string };
    if (!stage || !VALID_STAGES.has(stage)) return res.status(400).json({ message: "Неверный этап" });
    const existing = await storage.getCandidate(req.params.id);
    if (!existing) return res.status(404).json({ message: "Кандидат не найден" });
    const c = await storage.updateCandidate(req.params.id, {
      stage, ...(rejectReason !== undefined ? { rejectReason } : {}),
    });
    if (!c) return res.status(404).json({ message: "Кандидат не найден" });
    // Run stage change automation async so response is not blocked
    setImmediate(() => {
      onStageChange(c, existing.stage, stage, "user").catch((err) =>
        console.error("[routes] onStageChange error:", err)
      );
    });
    res.json(c);
  });

  // ---------- Candidate Tasks ----------
  app.get("/api/candidates/:id/tasks", async (req, res) => {
    res.json(await storage.getTasks(req.params.id));
  });
  app.post("/api/candidates/:id/tasks", async (req, res) => {
    try {
      const candidateId = req.params.id;
      const { assigneeId, title, description, dueAt } = req.body as {
        assigneeId: string; title: string; description?: string; dueAt: string;
      };
      if (!assigneeId || !title || !dueAt) {
        return res.status(400).json({ message: "assigneeId, title, dueAt обязательны" });
      }
      const task = await storage.createTask({
        candidateId,
        assigneeId,
        title,
        description: description ?? "",
        dueAt,
        status: "open",
        source: "manual",
        triggerStage: null,
      });
      res.status(201).json(task);
    } catch (err) {
      res.status(500).json({ message: "Ошибка создания задачи" });
    }
  });

  // ---------- Tasks (by id) ----------
  app.patch("/api/tasks/:id", async (req, res) => {
    const task = await storage.getTask(req.params.id);
    if (!task) return res.status(404).json({ message: "Задача не найдена" });
    const update: Partial<typeof task> = {};
    if (req.body.status) update.status = req.body.status;
    if (req.body.title) update.title = req.body.title;
    if (req.body.description !== undefined) update.description = req.body.description;
    if (req.body.dueAt) update.dueAt = req.body.dueAt;
    if (req.body.status === "done") update.completedAt = new Date().toISOString();
    const updated = await storage.updateTask(req.params.id, update);
    res.json(updated);
  });

  // ---------- Stage Events ----------
  app.get("/api/candidates/:id/stage-events", async (req, res) => {
    res.json(await storage.getStageEvents(req.params.id));
  });

  // ---------- Automations (scheduled_actions) ----------
  app.get("/api/candidates/:id/automations", async (req, res) => {
    res.json(await storage.getScheduledActions(req.params.id));
  });

  // ---------- Telegram link-token ----------
  app.post("/api/candidates/:id/link-token", async (req, res) => {
    const candidate = await storage.getCandidate(req.params.id);
    if (!candidate) return res.status(404).json({ message: "Кандидат не найден" });
    const token = randomBytes(16).toString("hex");
    await storage.updateCandidate(req.params.id, { linkToken: token });
    const botUsername = getBotUsername();
    res.json({
      token,
      deepLink: `https://t.me/${botUsername}?start=${token}`,
      botUsername,
    });
  });

  // ---------- CRM Users ----------
  app.get("/api/users", async (_req, res) => {
    res.json(await storage.getCrmUsers());
  });
  app.patch("/api/users/:id", async (req, res) => {
    const user = await storage.getCrmUser(req.params.id);
    if (!user) return res.status(404).json({ message: "Пользователь не найден" });
    const updated = await storage.updateCrmUser(req.params.id, req.body);
    res.json(updated);
  });

  // ---------- Stages ----------
  app.get("/api/stages", async (_req, res) => {
    res.json([
      { key: "form_filled", label: "Анкета заполнена", color: "blue", roleOwner: "hr_manager" },
      { key: "in_work", label: "Взяли в работу", color: "cyan", roleOwner: "hr_manager" },
      { key: "video_interview", label: "Видеоинтервью", color: "indigo", roleOwner: "hr_manager" },
      { key: "studio_demo", label: "Демо-погружение в студии", color: "violet", roleOwner: "uk" },
      { key: "theory", label: "Выдаём теорию", color: "purple", roleOwner: "uk" },
      { key: "exam_scheduled", label: "Назначен экзамен", color: "pink", roleOwner: "uk" },
      { key: "reexam", label: "Переэкзаменовка", color: "amber", roleOwner: "trainer_1" },
      { key: "trainer_onboarding", label: "Обучение тренером", color: "orange", roleOwner: "trainer_2" },
      { key: "studio_practice", label: "Практика в студии", color: "teal", roleOwner: "uk" },
      { key: "scheduled", label: "Выход в график", color: "emerald", roleOwner: "manager" },
      { key: "reserve", label: "Резерв", color: "gray", roleOwner: "uk" },
      { key: "rejected", label: "Отказ", color: "red", roleOwner: "uk" },
      { key: "official", label: "Офиц-ое трудоустройство", color: "green", roleOwner: "manager" },
      { key: "dismissed", label: "Увольнение", color: "slate", roleOwner: "manager" },
    ]);
  });

  // ---------- Documents ----------
  app.get("/api/candidates/:id/documents", async (req, res) => {
    res.json(await storage.getDocuments(req.params.id));
  });
  app.post("/api/candidates/:id/documents", async (req, res) => {
    const body = { ...req.body, candidateId: req.params.id };
    const parsed = insertDocumentSchema.safeParse(body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    const doc = await storage.createDocument(parsed.data);
    await storage.createActivity({
      candidateId: req.params.id, type: "document_uploaded",
      description: `Загружен документ: ${doc.fileName}`, meta: null,
    });
    res.status(201).json(doc);
  });
  app.patch("/api/documents/:id", async (req, res) => {
    const doc = await storage.updateDocument(req.params.id, req.body);
    if (!doc) return res.status(404).json({ message: "Документ не найден" });
    res.json(doc);
  });
  app.delete("/api/documents/:id", async (req, res) => {
    await storage.deleteDocument(req.params.id);
    res.status(204).end();
  });

  // ---------- Messages ----------
  app.get("/api/candidates/:id/messages", async (req, res) => {
    res.json(await storage.getMessages(req.params.id));
  });
  app.post("/api/candidates/:id/messages", async (req, res) => {
    const candidateId = req.params.id;
    const isHh = req.body?.channel === "hh";
    const body = {
      ...req.body,
      candidateId,
      direction: "out",
      source: isHh ? "hh" : (req.body?.source ?? null),
      deliveryStatus: isHh ? "pending" : (req.body?.deliveryStatus ?? "local"),
    };
    const parsed = insertMessageSchema.safeParse(body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    let msg = await storage.createMessage(parsed.data);

    if (isHh) {
      try {
        const ref = await storage.getExternalRefByEntity("candidate", candidateId, "hh", "negotiation");
        const integration = await storage.getIntegration("hh");
        if (!ref) {
          msg = (await storage.updateMessage(msg.id, { deliveryStatus: "failed" })) ?? msg;
          console.warn(`[hh] no negotiation ref for candidate ${candidateId}`);
        } else if (!integration || integration.status !== "connected") {
          msg = (await storage.updateMessage(msg.id, { deliveryStatus: "failed" })) ?? msg;
          console.warn("[hh] integration not connected");
        } else {
          const client = new HhClient(integration);
          await client.sendMessage(ref.externalId, msg.text);
          msg = (await storage.updateMessage(msg.id, { deliveryStatus: "delivered" })) ?? msg;
        }
      } catch (err) {
        console.error(`[hh] failed to deliver message for candidate ${candidateId}:`, err);
        msg = (await storage.updateMessage(msg.id, { deliveryStatus: "failed" })) ?? msg;
      }
    }

    const channelLabel = msg.channel === "telegram" ? "Telegram"
      : msg.channel === "telegram_bot" ? "Telegram Bot"
      : msg.channel === "avito" ? "Avito"
      : msg.channel === "hh" ? "hh.ru" : msg.channel;
    await storage.createActivity({
      candidateId, type: "message",
      description: `Отправлено сообщение (${channelLabel})`,
      meta: null,
    });
    res.status(201).json(msg);
  });

  // ---------- Activities ----------
  app.get("/api/candidates/:id/activities", async (req, res) => {
    res.json(await storage.getActivities(req.params.id));
  });

  // ---------- Dashboard ----------
  app.get("/api/dashboard/stats", async (_req, res) => {
    const all = await storage.getCandidates();
    const vacs = await storage.getVacancies();
    const byStage: Record<string, number> = {};
    for (const key of Array.from(VALID_STAGES)) byStage[key] = 0;
    const bySource: Record<string, number> = { avito: 0, hh: 0, telegram: 0, manual: 0 };
    let officialThisMonth = 0;
    let newThisWeek = 0;
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 86400000);
    const monthAgo = new Date(now.getTime() - 30 * 86400000);

    for (const c of all) {
      byStage[c.stage] = (byStage[c.stage] || 0) + 1;
      bySource[c.source] = (bySource[c.source] || 0) + 1;
      const created = new Date(c.createdAt);
      if (c.stage === "official" && created >= monthAgo) officialThisMonth++;
      if (c.stage === "form_filled" && created >= weekAgo) newThisWeek++;
    }
    // fallback so dashboard is never empty for seeded data
    if (officialThisMonth === 0) officialThisMonth = byStage.official ?? 0;
    if (newThisWeek === 0) newThisWeek = byStage.form_filled ?? 0;

    const inWork = all.filter((c) => !["reserve", "rejected", "official", "dismissed"].includes(c.stage)).length;

    res.json({
      totalCandidates: all.length,
      byStage,
      bySource,
      hiredThisMonth: officialThisMonth,
      officialThisMonth,
      newThisWeek,
      inWork,
      activeVacancies: vacs.filter((v) => v.status === "active").length,
    });
  });

  app.get("/api/dashboard/recent", async (_req, res) => {
    res.json(await storage.getRecentActivities(10));
  });

  // ---------- Integration stubs ----------
  app.post("/api/integrations/telegram/send", async (req, res) => {
    const { chatId, text } = req.body as { chatId?: string; text?: string };
    const tg = getTelegram();
    if (tg && chatId && text) {
      try {
        const result = await tg.sendMessage(chatId, text);
        return res.json({ ok: result.ok, messageId: result.message_id });
      } catch (err) {
        return res.status(500).json({ ok: false, error: String(err) });
      }
    }
    res.json({ ok: true, messageId: randomUUID(), status: "queued (dry-run)" });
  });

  // Telegram webhook (inbound updates from Telegram)
  app.post("/api/webhooks/telegram", async (req, res) => {
    // Respond 200 immediately so Telegram doesn't retry
    res.status(200).json({ ok: true });
    setImmediate(async () => {
      try {
        const update = req.body as {
          message?: {
            chat?: { id?: number; username?: string };
            text?: string;
            from?: { id?: number; username?: string; first_name?: string };
          };
        };
        if (!update?.message) return;
        const msg = update.message;
        const chatId = String(msg.chat?.id ?? "");
        const text = msg.text ?? "";
        const username = msg.chat?.username ?? msg.from?.username ?? null;
        const botUsername = getBotUsername();

        // /start <token> flow — link candidate
        if (text.startsWith("/start ")) {
          const token = text.slice(7).trim();
          const candidate = await storage.getCandidateByLinkToken(token);
          if (candidate) {
            // Link the candidate
            await storage.updateCandidate(candidate.id, { telegramChatId: chatId });
            await storage.upsertTelegramLink({
              candidateId: candidate.id,
              chatId,
              username,
              linkedAt: new Date().toISOString(),
              botUsername,
            });
            // Record activity
            await storage.createActivity({
              candidateId: candidate.id,
              type: "message",
              description: `Telegram привязан: chat_id ${chatId}${username ? " (@" + username + ")" : ""}`,
              meta: JSON.stringify({ channel: "telegram_bot", chatId, username }),
            });
            // Send welcome
            const tg = getTelegram();
            if (tg) {
              await tg.sendMessage(chatId, `Добро пожаловать, ${candidate.fullName}! Ваш аккаунт успешно привязан к системе Skin Line HR.`);
            }
          } else {
            // No match — just acknowledge
            const tg = getTelegram();
            if (tg) {
              await tg.sendMessage(chatId, "Ссылка недействительна или устарела. Запросите новую ссылку у HR-менеджера.");
            }
          }
          return;
        }

        // Regular incoming message — find candidate by chat_id
        const candidate = await storage.getCandidateByTelegramChatId(chatId);
        if (candidate) {
          await storage.createMessage({
            candidateId: candidate.id,
            channel: "telegram_bot",
            direction: "in",
            text: text || "[медиафайл]",
            isRead: 0,
            deliveryStatus: "delivered",
            meta: JSON.stringify({ chatId, username }),
          });
        } else {
          // Unmatched message — log only
          console.log(`[telegram-webhook] Unmatched message from chatId=${chatId}: ${text.substring(0, 50)}`);
        }
      } catch (err) {
        console.error("[telegram-webhook] Processing error:", err);
      }
    });
  });

  // Telegram webhook setup
  app.post("/api/integrations/telegram/setup", async (req, res) => {
    const secret = req.headers["x-setup-secret"] ?? req.body?.secret;
    if (process.env.SETUP_SECRET && secret !== process.env.SETUP_SECRET) {
      return res.status(403).json({ message: "Forbidden" });
    }
    const tg = getTelegram();
    if (!tg) return res.status(400).json({ message: "TELEGRAM_BOT_TOKEN не задан" });
    try {
      const webhookUrl = "https://api.skinline-hr.ru/api/webhooks/telegram";
      await tg.setWebhook(webhookUrl);
      const me = await tg.getMe();
      res.json({ ok: true, webhook: webhookUrl, bot: me });
    } catch (err) {
      res.status(500).json({ message: "Ошибка регистрации webhook", detail: String(err) });
    }
  });

  // ---------- Avito integration ----------
  app.post("/api/integrations/avito/sync", async (_req, res) => {
    if (!avitoEnvConfigured()) {
      return res.status(400).json({
        message: "Не настроены переменные окружения для Avito. Проверьте .env.",
      });
    }
    try {
      const result = await pollAvitoUnread(50);
      res.json({
        ok: true,
        chatsProcessed: result.chatsProcessed,
        imported: result.messagesIngested,
        ingestedCount: result.messagesIngested,
      });
    } catch (err) {
      console.error("[avito] manual sync failed:", err);
      res.status(502).json({
        message: "Ошибка синхронизации с Avito",
        detail: (err as Error).message,
      });
    }
  });

  app.get("/api/integrations/avito/chats", async (req, res) => {
    if (!avitoEnvConfigured()) {
      return res.status(400).json({ message: "Avito не настроен" });
    }
    try {
      const integ = await storage.getIntegration("avito");
      const client = new AvitoClient((integ ?? null) as any);
      const userId = parseInt(
        (integ?.accountId || process.env.AVITO_USER_ID || "0"),
        10,
      );
      if (!userId) return res.status(400).json({ message: "AVITO_USER_ID не задан" });
      const limit = Math.min(parseInt(String(req.query.limit ?? "50"), 10) || 50, 100);
      const unreadOnly = String(req.query.unread_only ?? "false") === "true";
      const data = await client.getChats({ userId, limit, unreadOnly });
      res.json(data);
    } catch (err) {
      console.error("[avito] list chats failed:", err);
      res.status(502).json({ message: "Не удалось получить чаты Avito" });
    }
  });

  app.post("/api/integrations/avito/chats/:chatId/reply", async (req, res) => {
    if (!avitoEnvConfigured()) {
      return res.status(400).json({ message: "Avito не настроен" });
    }
    const chatId = req.params.chatId;
    const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";
    if (!text) return res.status(400).json({ message: "Пустое сообщение" });
    try {
      const result = await sendAvitoReply({ chatId, text });
      res.json(result);
    } catch (err) {
      console.error("[avito] reply failed:", err);
      res.status(502).json({
        message: "Не удалось отправить сообщение в Avito",
        detail: (err as Error).message,
      });
    }
  });

  app.post("/api/webhooks/avito", async (req, res) => {
    const body: any = req.body ?? {};
    const value = body?.payload?.value;
    const externalId =
      (value?.content?.id && String(value.content.id)) ||
      (typeof body.id === "string" && body.id) ||
      null;

    let stored;
    try {
      stored = await storage.createWebhookEvent({
        source: "avito",
        eventType: String(body?.payload?.type || "unknown"),
        externalId,
        payload: JSON.stringify(body),
        status: "pending",
        attempts: 0,
        lastError: null,
      });
    } catch (err) {
      console.error("[avito] failed to record webhook event:", err);
      return res.status(200).json({ ok: true });
    }

    res.status(200).json({ ok: true });

    setImmediate(async () => {
      try {
        await processAvitoWebhook(body as AvitoWebhookEvent);
      } catch (err) {
        console.error(`[avito] async webhook processing failed for ${stored!.id}:`, err);
      }
    });
  });

  app.post("/api/integrations/avito/poll", async (_req, res) => {
    if (!avitoEnvConfigured()) {
      return res.status(400).json({ message: "Avito не настроен" });
    }
    try {
      const result = await pollAvitoUnread(50);
      res.json({ ok: true, ...result });
    } catch (err) {
      console.error("[avito] poll failed:", err);
      res.status(502).json({ message: "Ошибка опроса Avito" });
    }
  });

  app.get("/api/integrations/avito/self", async (_req, res) => {
    if (!avitoEnvConfigured()) {
      return res.status(400).json({ message: "Avito не настроен" });
    }
    try {
      const integ = await storage.getIntegration("avito");
      const client = new AvitoClient((integ ?? null) as any);
      const self = await client.getSelf();
      res.json({ ok: true, self });
    } catch (err) {
      res.status(502).json({
        message: "Avito недоступен",
        detail: (err as Error).message,
      });
    }
  });

  // ---------- hh.ru integration ----------
  app.get("/api/integrations", async (_req, res) => {
    const rows = await storage.getIntegrations();
    const bySource = new Map(rows.map((r) => [r.source, r]));
    const sources = ["hh", "avito", "telegram"];
    res.json(sources.map((s) => {
      const row = bySource.get(s);
      return row ? maskIntegration(row) : placeholderIntegration(s);
    }));
  });

  app.get("/api/integrations/:source", async (req, res) => {
    const row = await storage.getIntegration(req.params.source);
    if (!row) return res.json(placeholderIntegration(req.params.source));
    res.json(maskIntegration(row));
  });

  app.get("/api/integrations/hh/connect", async (_req, res) => {
    if (!hhEnvConfigured()) {
      return res.status(400).json({
        message: "Не настроены переменные окружения для hh.ru. Проверьте .env.",
      });
    }
    try {
      const state = randomUUID();
      await storage.createOauthState(state, "hh");
      const url = new HhClient().getAuthorizeUrl(state);
      res.redirect(302, url);
    } catch (err) {
      console.error("[hh] connect failed:", err);
      res.redirect(302, `${FRONTEND_SETTINGS_URL}?error=hh`);
    }
  });

  app.get("/api/integrations/hh/callback", async (req, res) => {
    const code = typeof req.query.code === "string" ? req.query.code : null;
    const state = typeof req.query.state === "string" ? req.query.state : null;
    try {
      if (!code || !state) throw new Error("missing code or state");
      const stored = await storage.getOauthState(state);
      if (!stored || stored.source !== "hh") throw new Error("invalid state");
      await storage.deleteOauthState(state);
      const STATE_TTL_MS = 10 * 60 * 1000;
      if (Date.now() - new Date(stored.createdAt).getTime() > STATE_TTL_MS) {
        throw new Error("state expired");
      }

      const tokens = await new HhClient().exchangeCode(code);
      const tokenExpiresAt = new Date(Date.now() + tokens.expires_in * 1000).toISOString();

      let integration = await storage.upsertIntegration("hh", {
        status: "connected",
        accessToken: encrypt(tokens.access_token),
        refreshToken: encrypt(tokens.refresh_token),
        tokenExpiresAt,
        lastError: null,
      });

      try {
        const client = new HhClient(integration);
        const me = await client.me();
        const accountName =
          [me.first_name, me.last_name].filter(Boolean).join(" ").trim() ||
          me.email ||
          "Аккаунт hh.ru";
        const meta = JSON.stringify({
          employerId: me.employer?.id ?? null,
          employerName: me.employer?.name ?? null,
          managerId: me.manager?.id ?? null,
          email: me.email ?? null,
        });
        integration = (await storage.updateIntegration(integration.id, {
          accountId: me.employer?.id ?? me.id ?? null,
          accountName,
          meta,
        })) ?? integration;
      } catch (meErr) {
        console.warn("[hh] /me lookup failed during callback:", meErr);
      }

      res.redirect(302, `${FRONTEND_SETTINGS_URL}?connected=hh`);
    } catch (err) {
      console.error("[hh] callback failed:", err);
      res.redirect(302, `${FRONTEND_SETTINGS_URL}?error=hh`);
    }
  });

  app.post("/api/integrations/hh/disconnect", async (_req, res) => {
    try {
      const existing = await storage.getIntegration("hh");
      if (!existing) return res.json(placeholderIntegration("hh"));
      const updated = await storage.updateIntegration(existing.id, {
        status: "disconnected",
        accessToken: null,
        refreshToken: null,
        tokenExpiresAt: null,
        lastError: null,
      });
      res.json(updated ? maskIntegration(updated) : placeholderIntegration("hh"));
    } catch (err) {
      console.error("[hh] disconnect failed:", err);
      res.status(500).json({ message: "Не удалось отключить hh.ru" });
    }
  });

  app.post("/api/integrations/hh/sync", async (_req, res) => {
    const integration = await storage.getIntegration("hh");
    if (!integration || integration.status !== "connected") {
      return res.status(400).json({
        message: "hh.ru не подключён. Подключите аккаунт в настройках.",
      });
    }
    try {
      const result = await pollAll();
      res.json({
        ok: true,
        ingestedCount: result.ingestedCount,
        createdCount: result.createdCount,
        imported: result.createdCount,
      });
    } catch (err) {
      console.error("[hh] manual sync failed:", err);
      res.status(502).json({ message: "Ошибка синхронизации с hh.ru" });
    }
  });

  app.post("/api/integrations/hh/webhook", async (req, res) => {
    const signature =
      req.header("X-Hh-Signature") || req.header("x-hh-signature") || null;
    if (!signature) {
      console.warn("[hh] webhook received without X-Hh-Signature header");
    }
    const body: any = req.body ?? {};
    const externalId =
      (typeof body.negotiation_id === "string" && body.negotiation_id) ||
      (typeof body.negotiationId === "string" && body.negotiationId) ||
      (body?.payload && typeof body.payload.negotiation_id === "string" && body.payload.negotiation_id) ||
      null;
    let event;
    try {
      event = await storage.createWebhookEvent({
        source: "hh",
        eventType: String(body.type || body.action || body.event || "unknown"),
        externalId,
        payload: JSON.stringify(body),
        status: "pending",
        attempts: 0,
        lastError: null,
      });
    } catch (err) {
      console.error("[hh] failed to record webhook event:", err);
      return res.status(200).json({ ok: true });
    }
    res.status(200).json({ ok: true });
    setImmediate(() => {
      processWebhookEvent(event!.id).catch((err) =>
        console.error(`[hh] async webhook processing failed for ${event!.id}:`, err),
      );
    });
  });

  app.get("/api/candidates/:id/sync", async (req, res) => {
    const candidateId = req.params.id;
    try {
      const ref = await storage.getExternalRefByEntity(
        "candidate", candidateId, "hh", "negotiation",
      );
      if (!ref) {
        return res.status(400).json({
          message: "У кандидата нет связанного отклика hh.ru",
        });
      }
      const integration = await storage.getIntegration("hh");
      if (!integration || integration.status !== "connected") {
        return res.status(400).json({
          message: "hh.ru не подключён. Подключите аккаунт в настройках.",
        });
      }
      const client = new HhClient(integration);
      const result = await ingestNegotiation(client, ref.externalId);
      res.json({ ok: true, newMessages: result.newMessages ?? 0 });
    } catch (err) {
      console.error(`[hh] candidate sync failed for ${candidateId}:`, err);
      res.status(502).json({ message: "Ошибка синхронизации с hh.ru" });
    }
  });

  return httpServer;
}
