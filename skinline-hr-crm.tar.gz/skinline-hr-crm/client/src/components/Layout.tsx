import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { LayoutDashboard, Users, Briefcase, Settings, Moon, Sun } from "lucide-react";
import { Logo } from "./Logo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useTheme } from "@/components/ThemeProvider";
import type { Candidate } from "@shared/schema";

const NAV = [
  { href: "/", label: "Дашборд", icon: LayoutDashboard, testid: "nav-dashboard" },
  { href: "/candidates", label: "Кандидаты", icon: Users, testid: "nav-candidates" },
  { href: "/vacancies", label: "Вакансии", icon: Briefcase, testid: "nav-vacancies" },
  { href: "/settings", label: "Настройки", icon: Settings, testid: "nav-settings" },
];

export function Layout({ children, title, actions }: { children: React.ReactNode; title: string; actions?: React.ReactNode }) {
  const [location] = useLocation();
  const { theme, toggle } = useTheme();
  const { data: candidates } = useQuery<Candidate[]>({ queryKey: ["/api/candidates"] });
  const newCount = (candidates ?? []).filter((c) => c.stage === "new").length;

  const isActive = (href: string) =>
    href === "/" ? location === "/" : location.startsWith(href);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background text-foreground">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar md:flex">
        <div className="px-5 py-5">
          <Logo />
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {NAV.map((item) => {
            const active = isActive(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                data-testid={item.testid}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors hover-elevate",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground",
                )}
              >
                <Icon className="h-[18px] w-[18px]" />
                <span className="marshall-display flex-1 text-xs">{item.label}</span>
                {item.href === "/candidates" && newCount > 0 && (
                  <Badge
                    data-testid="badge-new-count"
                    className={cn(
                      "h-5 min-w-5 justify-center rounded-full px-1.5 text-[11px]",
                      active ? "bg-white/25 text-white" : "bg-primary text-primary-foreground",
                    )}
                  >
                    {newCount}
                  </Badge>
                )}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <div className="rounded-xl bg-sidebar-accent px-3 py-2.5 text-xs text-sidebar-accent-foreground">
            <div className="marshall-display text-[11px]">Skin Line</div>
            <div className="text-muted-foreground">Сеть салонов красоты</div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 shrink-0 items-center gap-4 border-b border-border bg-background/80 px-5 backdrop-blur md:px-8">
          {/* Mobile logo */}
          <div className="md:hidden">
            <Logo collapsed />
          </div>
          <h1 className="marshall-display truncate text-base leading-tight" data-testid="text-page-title">{title}</h1>
          <div className="ml-auto flex items-center gap-2">
            {actions}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggle}
              data-testid="button-theme-toggle"
              aria-label="Сменить тему"
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
          </div>
        </header>

        {/* Mobile nav */}
        <nav className="flex gap-1 overflow-x-auto border-b border-border bg-background px-3 py-2 md:hidden">
          {NAV.map((item) => {
            const active = isActive(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "marshall-display flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs",
                  active ? "bg-primary text-primary-foreground" : "text-muted-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
