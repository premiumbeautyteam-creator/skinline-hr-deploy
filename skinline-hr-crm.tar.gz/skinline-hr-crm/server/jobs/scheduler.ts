// Background job scheduler for integration sync, token refresh, OAuth-state
// cleanup and webhook processing. Uses node-cron. Every job is wrapped in
// try/catch so a single failure never crashes the process or stops the cron.

import cron from "node-cron";
import { storage } from "../storage";
import { pollAll, processWebhookEvent } from "../integrations/hh-ingest";
import { HhClient, hhEnvConfigured } from "../integrations/hh";

// Use ReturnType to avoid relying on the node-cron namespace types, which are
// not exposed consistently across @types/node-cron versions.
const tasks: ReturnType<typeof cron.schedule>[] = [];

async function runSafely(name: string, fn: () => Promise<void>) {
  try {
    await fn();
  } catch (err) {
    console.error(`[${name}] job error:`, err);
  }
}

// 1) Poll hh.ru negotiations every 3 minutes.
function jobPollHh() {
  return cron.schedule("*/3 * * * *", () =>
    runSafely("job-poll-hh", async () => {
      if (!hhEnvConfigured()) return; // nothing to do without credentials
      const { ingestedCount, createdCount } = await pollAll();
      if (ingestedCount > 0) {
        console.log(`[job-poll-hh] ingested=${ingestedCount} created=${createdCount}`);
      }
    }),
  );
}

// 2) Clean up expired oauth_states (>10 min old) every 10 minutes.
function jobCleanOauthStates() {
  return cron.schedule("*/10 * * * *", () =>
    runSafely("job-clean-oauth", async () => {
      const cutoff = new Date(Date.now() - 10 * 60 * 1000).toISOString();
      const removed = await storage.deleteExpiredOauthStates(cutoff);
      if (removed > 0) console.log(`[job-clean-oauth] removed ${removed} expired states`);
    }),
  );
}

// 3) Proactively refresh tokens expiring within 24h, every 60 minutes.
function jobRefreshTokens() {
  return cron.schedule("0 * * * *", () =>
    runSafely("job-refresh-tokens", async () => {
      if (!hhEnvConfigured()) return;
      const soon = Date.now() + 24 * 60 * 60 * 1000;
      const integrations = (await storage.getIntegrations()).filter(
        (i) =>
          i.source === "hh" &&
          (i.status === "connected" || i.status === "error") &&
          i.refreshToken &&
          i.tokenExpiresAt &&
          new Date(i.tokenExpiresAt).getTime() <= soon,
      );
      for (const integration of integrations) {
        try {
          const client = new HhClient(integration);
          await client.refresh();
          console.log(`[job-refresh-tokens] refreshed token for integration ${integration.id}`);
        } catch (err) {
          console.error(`[job-refresh-tokens] refresh failed for ${integration.id}:`, err);
        }
      }
    }),
  );
}

// 4) Process pending webhook events (max 10 per tick) every 30 seconds.
function jobProcessWebhooks() {
  return cron.schedule("*/30 * * * * *", () =>
    runSafely("job-process-webhooks", async () => {
      const pending = await storage.getPendingWebhookEvents(10);
      for (const event of pending) {
        await processWebhookEvent(event.id);
      }
    }),
  );
}

/** Start all background jobs. Safe to call once after the server is listening. */
export function startScheduler() {
  if (tasks.length > 0) return; // idempotent
  tasks.push(jobPollHh(), jobCleanOauthStates(), jobRefreshTokens(), jobProcessWebhooks());
  console.log("[scheduler] background jobs started (poll/clean/refresh/webhooks)");
}

/** Stop all background jobs (used in tests / graceful shutdown). */
export function stopScheduler() {
  for (const t of tasks) t.stop();
  tasks.length = 0;
}
