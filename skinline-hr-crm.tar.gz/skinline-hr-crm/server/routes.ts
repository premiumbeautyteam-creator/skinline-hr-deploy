import type { Express, Request } from "express";
import type { Server } from 'node:http';
import { storage, seedDatabase } from "./storage";
import {
  insertVacancySchema, insertCandidateSchema, insertDocumentSchema, insertMessageSchema,
} from "@shared/schema";
import type { Integration, IntegrationPublic } from "@shared/schema";
import { randomUUID } from "node:crypto";
import { HhClient, hhEnvConfigured } from "./integrations/hh";
import { pollAll, ingestNegotiation, processWebhookEvent } from "./integrations/hh-ingest";
import { encrypt } from "./lib/crypto";

// Strip tokens from an integration record before returning it over the API.
function maskIntegration(i: Integration): IntegrationPublic {
  const { accessToken, refreshToken, ...rest } = i;
  return { ...rest, hasTokens: Boolean(accessToken && refreshToken) };
}

// Placeholder/default integration shape for sources that have no row yet.
function placeholderIntegration(source: string): IntegrationPublic {
  const now = new Date().toISOString();
  return {
    id: "", source, status: "disconnected",
    accountId: null, accountName: null, tokenExpiresAt: null,
    lastSyncAt: null, lastError: null, meta: null,
    createdAt: now, updatedAt: now, hasTokens: false,
  };
}

const FRONTEND_SETTINGS_URL = "/#/settings";

const STAGE_LABELS: Record<string, string> = {
  new: "Новый", screening: "Скрининг", test_service: "Тестовая услуга",
  documents: "Документы", offer: "Оффер", hired: "Принят", rejected: "Отказ",
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  seedDatabase();

  // ---------- Vacancies ----------
  app.get("/api/vacancies", async (_req, res) => {
    res.json(await storage.getVacancies());
  });
  app.get("/api/vacancies/:id", async (req, res) => {
    const v = await storage.getVacancy(req.params.id);
    if (!v) return res.status(404).json({ message: "Вакансия не найдена" });
    res.json(v);
  });
  app.post("/api/vacancies", async (req, res) => {
    const parsed = insertVacancySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    res.status(201).json(await storage.createVacancy(parsed.data));
  });
  app.patch("/api/vacancies/:id", async (req, res) => {
    const parsed = insertVacancySchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные" });
    const v = await storage.updateVacancy(req.params.id, parsed.data);
    if (!v) return res.status(404).json({ message: "Вакансия не найдена" });
    res.json(v);
  });
  app.delete("/api/vacancies/:id", async (req, res) => {
    await storage.deleteVacancy(req.params.id);
    res.status(204).end();
  });

  // ---------- Candidates ----------
  app.get("/api/candidates", async (req, res) => {
    const { stage, vacancyId, source } = req.query as Record<string, string>;
    res.json(await storage.getCandidates({ stage, vacancyId, source }));
  });
  app.get("/api/candidates/:id", async (req, res) => {
    const c = await storage.getCandidate(req.params.id);
    if (!c) return res.status(404).json({ message: "Кандидат не найден" });
    res.json(c);
  });
  app.post("/api/candidates", async (req, res) => {
    const parsed = insertCandidateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    const c = await storage.createCandidate(parsed.data);
    await storage.createActivity({
      candidateId: c.id, type: "stage_change",
      description: "Кандидат добавлен вручную", meta: null,
    });
    res.status(201).json(c);
  });
  app.patch("/api/candidates/:id", async (req, res) => {
    const parsed = insertCandidateSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные" });
    const c = await storage.updateCandidate(req.params.id, parsed.data);
    if (!c) return res.status(404).json({ message: "Кандидат не найден" });
    res.json(c);
  });
  app.delete("/api/candidates/:id", async (req, res) => {
    await storage.deleteCandidate(req.params.id);
    res.status(204).end();
  });

  // stage change
  app.patch("/api/candidates/:id/stage", async (req, res) => {
    const { stage, rejectReason } = req.body as { stage: string; rejectReason?: string };
    if (!stage || !STAGE_LABELS[stage]) return res.status(400).json({ message: "Неверный этап" });
    const c = await storage.updateCandidate(req.params.id, {
      stage, ...(rejectReason !== undefined ? { rejectReason } : {}),
    });
    if (!c) return res.status(404).json({ message: "Кандидат не найден" });
    await storage.createActivity({
      candidateId: c.id, type: "stage_change",
      description: `Этап изменён на «${STAGE_LABELS[stage]}»`,
      meta: JSON.stringify({ stage }),
    });
    res.json(c);
  });

  // ---------- Documents ----------
  app.get("/api/candidates/:id/documents", async (req, res) => {
    res.json(await storage.getDocuments(req.params.id));
  });
  app.post("/api/candidates/:id/documents", async (req, res) => {
    const body = { ...req.body, candidateId: req.params.id };
    const parsed = insertDocumentSchema.safeParse(body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    const doc = await storage.createDocument(parsed.data);
    await storage.createActivity({
      candidateId: req.params.id, type: "document_uploaded",
      description: `Загружен документ: ${doc.fileName}`, meta: null,
    });
    res.status(201).json(doc);
  });
  app.patch("/api/documents/:id", async (req, res) => {
    const doc = await storage.updateDocument(req.params.id, req.body);
    if (!doc) return res.status(404).json({ message: "Документ не найден" });
    res.json(doc);
  });
  app.delete("/api/documents/:id", async (req, res) => {
    await storage.deleteDocument(req.params.id);
    res.status(204).end();
  });

  // ---------- Messages ----------
  app.get("/api/candidates/:id/messages", async (req, res) => {
    res.json(await storage.getMessages(req.params.id));
  });
  app.post("/api/candidates/:id/messages", async (req, res) => {
    const candidateId = req.params.id;
    const isHh = req.body?.channel === "hh";
    const body = {
      ...req.body,
      candidateId,
      direction: "out",
      source: isHh ? "hh" : (req.body?.source ?? null),
      // hh messages start as "pending" until delivery succeeds; others are local.
      deliveryStatus: isHh ? "pending" : (req.body?.deliveryStatus ?? "local"),
    };
    const parsed = insertMessageSchema.safeParse(body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные данные", errors: parsed.error.errors });
    let msg = await storage.createMessage(parsed.data);

    // Deliver to hh.ru if this is an hh-channel message and we have a negotiation link.
    if (isHh) {
      try {
        const ref = await storage.getExternalRefByEntity("candidate", candidateId, "hh", "negotiation");
        const integration = await storage.getIntegration("hh");
        if (!ref) {
          msg = (await storage.updateMessage(msg.id, { deliveryStatus: "failed" })) ?? msg;
          console.warn(`[hh] no negotiation ref for candidate ${candidateId}; message stored locally`);
        } else if (!integration || integration.status !== "connected") {
          msg = (await storage.updateMessage(msg.id, { deliveryStatus: "failed" })) ?? msg;
          console.warn("[hh] integration not connected; message stored locally");
        } else {
          const client = new HhClient(integration);
          await client.sendMessage(ref.externalId, msg.text);
          msg = (await storage.updateMessage(msg.id, { deliveryStatus: "delivered" })) ?? msg;
        }
      } catch (err) {
        console.error(`[hh] failed to deliver message for candidate ${candidateId}:`, err);
        msg = (await storage.updateMessage(msg.id, { deliveryStatus: "failed" })) ?? msg;
      }
    }

    const channelLabel = msg.channel === "telegram" ? "Telegram"
      : msg.channel === "avito" ? "Avito"
      : msg.channel === "hh" ? "hh.ru" : msg.channel;
    await storage.createActivity({
      candidateId, type: "message",
      description: `Отправлено сообщение (${channelLabel})`,
      meta: null,
    });
    res.status(201).json(msg);
  });

  // ---------- Activities ----------
  app.get("/api/candidates/:id/activities", async (req, res) => {
    res.json(await storage.getActivities(req.params.id));
  });

  // ---------- Dashboard ----------
  app.get("/api/dashboard/stats", async (_req, res) => {
    const all = await storage.getCandidates();
    const vacs = await storage.getVacancies();
    const byStage: Record<string, number> = {
      new: 0, screening: 0, test_service: 0, documents: 0, offer: 0, hired: 0, rejected: 0,
    };
    const bySource: Record<string, number> = { avito: 0, hh: 0, telegram: 0, manual: 0 };
    let hiredThisMonth = 0;
    let newThisWeek = 0;
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 86400000);
    for (const c of all) {
      byStage[c.stage] = (byStage[c.stage] || 0) + 1;
      bySource[c.source] = (bySource[c.source] || 0) + 1;
      const created = new Date(c.createdAt);
      if (c.stage === "hired" && created.getMonth() === now.getMonth() && created.getFullYear() === now.getFullYear()) hiredThisMonth++;
      if (created >= weekAgo) newThisWeek++;
    }
    // fallback so dashboard is never empty for seeded data
    if (hiredThisMonth === 0) hiredThisMonth = byStage.hired;
    if (newThisWeek === 0) newThisWeek = byStage.new;
    res.json({
      totalCandidates: all.length,
      byStage,
      bySource,
      hiredThisMonth,
      newThisWeek,
      activeVacancies: vacs.filter((v) => v.status === "active").length,
    });
  });

  app.get("/api/dashboard/recent", async (_req, res) => {
    res.json(await storage.getRecentActivities(10));
  });

  // ---------- Integration stubs ----------
  const mockNames = [
    { fullName: "Ирина Фёдорова", phone: "+7 916 777-11-22", exp: "4 года", city: "Москва" },
    { fullName: "Оксана Белова", phone: "+7 921 888-33-44", exp: "6 лет", city: "Санкт-Петербург" },
    { fullName: "Маргарита Сорокина", phone: "+7 917 999-55-66", exp: "3 года", city: "Казань" },
  ];

  async function fakePull(source: string, count: number) {
    const vacs = await storage.getVacancies();
    const created = [];
    for (let i = 0; i < count; i++) {
      const m = mockNames[i % mockNames.length];
      const c = await storage.createCandidate({
        fullName: m.fullName + " " + Math.floor(Math.random() * 90 + 10),
        phone: m.phone, email: null, city: m.city,
        vacancyId: vacs[i % vacs.length].id, source,
        sourceUrl: source === "avito" ? "https://www.avito.ru/rezume/example" : "https://hh.ru/resume/example",
        stage: "new", experience: m.exp, expectedSalary: null, rating: null,
        notes: null, tags: JSON.stringify([source === "avito" ? "новый отклик" : "hh.ru"]),
        rejectReason: null, avatarUrl: null,
      });
      await storage.createActivity({
        candidateId: c.id, type: "stage_change",
        description: `Импортирован из ${source === "avito" ? "Avito" : "hh.ru"}`, meta: null,
      });
      created.push(c);
    }
    return created;
  }

  app.post("/api/integrations/avito/sync", async (_req, res) => {
    console.log("TODO: connect real API — Avito");
    const n = 2 + Math.floor(Math.random() * 2);
    const created = await fakePull("avito", n);
    res.json({ ok: true, imported: created.length, candidates: created });
  });
  app.post("/api/integrations/telegram/send", async (req, res) => {
    console.log("TODO: connect real API — Telegram", req.body);
    res.json({ ok: true, messageId: randomUUID(), status: "sent (mock)" });
  });


  // ---------- hh.ru integration ----------

  // List all integrations (masked). Surfaces hh/avito/telegram even if no row exists yet.
  app.get("/api/integrations", async (_req, res) => {
    const rows = await storage.getIntegrations();
    const bySource = new Map(rows.map((r) => [r.source, r]));
    const sources = ["hh", "avito", "telegram"];
    res.json(sources.map((s) => {
      const row = bySource.get(s);
      return row ? maskIntegration(row) : placeholderIntegration(s);
    }));
  });

  // Get a single integration (masked).
  app.get("/api/integrations/:source", async (req, res) => {
    const row = await storage.getIntegration(req.params.source);
    if (!row) return res.json(placeholderIntegration(req.params.source));
    res.json(maskIntegration(row));
  });

  // Begin OAuth: create state, redirect to hh.ru authorize page.
  app.get("/api/integrations/hh/connect", async (_req, res) => {
    if (!hhEnvConfigured()) {
      return res.status(400).json({
        message: "Не настроены переменные окружения для hh.ru. Проверьте .env.",
      });
    }
    try {
      const state = randomUUID();
      await storage.createOauthState(state, "hh");
      const url = new HhClient().getAuthorizeUrl(state);
      res.redirect(302, url);
    } catch (err) {
      console.error("[hh] connect failed:", err);
      res.redirect(302, `${FRONTEND_SETTINGS_URL}?error=hh`);
    }
  });

  // OAuth callback: validate state, exchange code, persist encrypted tokens, fetch /me.
  app.get("/api/integrations/hh/callback", async (req, res) => {
    const code = typeof req.query.code === "string" ? req.query.code : null;
    const state = typeof req.query.state === "string" ? req.query.state : null;
    try {
      if (!code || !state) throw new Error("missing code or state");
      const stored = await storage.getOauthState(state);
      if (!stored || stored.source !== "hh") throw new Error("invalid state");
      await storage.deleteOauthState(state);
      // State is valid for 10 minutes from creation.
      const STATE_TTL_MS = 10 * 60 * 1000;
      if (Date.now() - new Date(stored.createdAt).getTime() > STATE_TTL_MS) {
        throw new Error("state expired");
      }

      const tokens = await new HhClient().exchangeCode(code);
      const tokenExpiresAt = new Date(Date.now() + tokens.expires_in * 1000).toISOString();

      // Upsert the integration as connected with encrypted tokens.
      let integration = await storage.upsertIntegration("hh", {
        status: "connected",
        accessToken: encrypt(tokens.access_token),
        refreshToken: encrypt(tokens.refresh_token),
        tokenExpiresAt,
        lastError: null,
      });

      // Fetch /me to populate the displayed account name + employer/manager ids.
      try {
        const client = new HhClient(integration);
        const me = await client.me();
        const accountName =
          [me.first_name, me.last_name].filter(Boolean).join(" ").trim() ||
          me.email ||
          "Аккаунт hh.ru";
        const meta = JSON.stringify({
          employerId: me.employer?.id ?? null,
          employerName: me.employer?.name ?? null,
          managerId: me.manager?.id ?? null,
          email: me.email ?? null,
        });
        integration = (await storage.updateIntegration(integration.id, {
          accountId: me.employer?.id ?? me.id ?? null,
          accountName,
          meta,
        })) ?? integration;
      } catch (meErr) {
        // Non-fatal: connection still works, we just lack display metadata.
        console.warn("[hh] /me lookup failed during callback:", meErr);
      }

      res.redirect(302, `${FRONTEND_SETTINGS_URL}?connected=hh`);
    } catch (err) {
      console.error("[hh] callback failed:", err);
      res.redirect(302, `${FRONTEND_SETTINGS_URL}?error=hh`);
    }
  });

  // Disconnect: null out tokens, set status disconnected.
  app.post("/api/integrations/hh/disconnect", async (_req, res) => {
    try {
      const existing = await storage.getIntegration("hh");
      if (!existing) return res.json(placeholderIntegration("hh"));
      const updated = await storage.updateIntegration(existing.id, {
        status: "disconnected",
        accessToken: null,
        refreshToken: null,
        tokenExpiresAt: null,
        lastError: null,
      });
      res.json(updated ? maskIntegration(updated) : placeholderIntegration("hh"));
    } catch (err) {
      console.error("[hh] disconnect failed:", err);
      res.status(500).json({ message: "Не удалось отключить hh.ru" });
    }
  });

  // Manual sync: pull active negotiations and ingest new responses.
  app.post("/api/integrations/hh/sync", async (_req, res) => {
    const integration = await storage.getIntegration("hh");
    if (!integration || integration.status !== "connected") {
      return res.status(400).json({
        message: "hh.ru не подключён. Подключите аккаунт в настройках.",
      });
    }
    try {
      const result = await pollAll();
      res.json({
        ok: true,
        ingestedCount: result.ingestedCount,
        createdCount: result.createdCount,
        // Backwards-compatible alias for older frontend code.
        imported: result.createdCount,
      });
    } catch (err) {
      console.error("[hh] manual sync failed:", err);
      res.status(502).json({ message: "Ошибка синхронизации с hh.ru" });
    }
  });

  // Webhook receiver. hh.ru posts negotiation/message events here.
  // We record the event and process it asynchronously so we always 200 fast.
  app.post("/api/integrations/hh/webhook", async (req, res) => {
    // hh.ru webhook signature header name is not fully documented; warn if absent.
    // TODO: verify X-Hh-Signature against HH_CLIENT_SECRET once hh confirms the
    // exact signing scheme (see INTEGRATIONS.md). For now we accept + log.
    const signature =
      req.header("X-Hh-Signature") || req.header("x-hh-signature") || null;
    if (!signature) {
      console.warn("[hh] webhook received without X-Hh-Signature header");
    }
    const body: any = req.body ?? {};
    const externalId =
      (typeof body.negotiation_id === "string" && body.negotiation_id) ||
      (typeof body.negotiationId === "string" && body.negotiationId) ||
      (body?.payload && typeof body.payload.negotiation_id === "string" && body.payload.negotiation_id) ||
      null;
    let event;
    try {
      event = await storage.createWebhookEvent({
        source: "hh",
        eventType: String(body.type || body.action || body.event || "unknown"),
        externalId,
        payload: JSON.stringify(body),
        status: "pending",
        attempts: 0,
        lastError: null,
      });
    } catch (err) {
      console.error("[hh] failed to record webhook event:", err);
      // Still 200 so hh.ru does not retry-storm us; we just dropped it.
      return res.status(200).json({ ok: true });
    }
    // Acknowledge immediately, then process out of band.
    res.status(200).json({ ok: true });
    setImmediate(() => {
      processWebhookEvent(event!.id).catch((err) =>
        console.error(`[hh] async webhook processing failed for ${event!.id}:`, err),
      );
    });
  });

  // Re-sync a single candidate's negotiation (messages) from hh.ru.
  app.get("/api/candidates/:id/sync", async (req, res) => {
    const candidateId = req.params.id;
    try {
      const ref = await storage.getExternalRefByEntity(
        "candidate", candidateId, "hh", "negotiation",
      );
      if (!ref) {
        return res.status(400).json({
          message: "У кандидата нет связанного отклика hh.ru",
        });
      }
      const integration = await storage.getIntegration("hh");
      if (!integration || integration.status !== "connected") {
        return res.status(400).json({
          message: "hh.ru не подключён. Подключите аккаунт в настройках.",
        });
      }
      const client = new HhClient(integration);
      const result = await ingestNegotiation(client, ref.externalId);
      res.json({ ok: true, newMessages: result.newMessages ?? 0 });
    } catch (err) {
      console.error(`[hh] candidate sync failed for ${candidateId}:`, err);
      res.status(502).json({ message: "Ошибка синхронизации с hh.ru" });
    }
  });

  return httpServer;
}
