import {
  vacancies, candidates, documents, messages, activities,
  integrations, externalRefs, oauthStates, webhookEvents,
} from '@shared/schema';
import type {
  Vacancy, InsertVacancy,
  Candidate, InsertCandidate,
  Document, InsertDocument,
  Message, InsertMessage,
  Activity, InsertActivity,
  Integration, InsertIntegration,
  ExternalRef, InsertExternalRef,
  OauthState,
  WebhookEvent, InsertWebhookEvent,
} from '@shared/schema';
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc, and, lt } from "drizzle-orm";
import { randomUUID } from "node:crypto";

const sqlite = new Database("data.db");
sqlite.pragma("journal_mode = WAL");

// Create tables if not present (template ships without migrations for our schema)
sqlite.exec(`
CREATE TABLE IF NOT EXISTS vacancies (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, city TEXT NOT NULL,
  salary TEXT NOT NULL, status TEXT NOT NULL, description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS candidates (
  id TEXT PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT,
  city TEXT NOT NULL, vacancy_id TEXT NOT NULL, source TEXT NOT NULL, source_url TEXT,
  stage TEXT NOT NULL, experience TEXT NOT NULL, expected_salary TEXT, rating INTEGER,
  notes TEXT, tags TEXT NOT NULL DEFAULT '[]', reject_reason TEXT, avatar_url TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, type TEXT NOT NULL,
  file_name TEXT NOT NULL, file_url TEXT NOT NULL, uploaded_at TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, channel TEXT NOT NULL,
  direction TEXT NOT NULL, text TEXT NOT NULL, sent_at TEXT NOT NULL,
  is_read INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS activities (
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, type TEXT NOT NULL,
  description TEXT NOT NULL, created_at TEXT NOT NULL, meta TEXT
);
CREATE TABLE IF NOT EXISTS integrations (
  id TEXT PRIMARY KEY, source TEXT NOT NULL, status TEXT NOT NULL,
  account_id TEXT, account_name TEXT, access_token TEXT, refresh_token TEXT,
  token_expires_at TEXT, last_sync_at TEXT, last_error TEXT, meta TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS external_refs (
  id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
  source TEXT NOT NULL, external_id TEXT NOT NULL, external_type TEXT NOT NULL,
  meta TEXT, created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_external_refs_unique
  ON external_refs (source, external_type, external_id);
CREATE TABLE IF NOT EXISTS oauth_states (
  state TEXT PRIMARY KEY, source TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS webhook_events (
  id TEXT PRIMARY KEY, source TEXT NOT NULL, event_type TEXT NOT NULL,
  external_id TEXT, payload TEXT NOT NULL, status TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT,
  received_at TEXT NOT NULL, processed_at TEXT
);
`);

// Lightweight migrations for columns added to pre-existing tables.
// SQLite has no "ADD COLUMN IF NOT EXISTS", so we inspect pragma table_info
// and add only the missing columns. This keeps existing seeded data intact.
function ensureColumn(table: string, column: string, ddl: string) {
  const cols = sqlite.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (!cols.some((c) => c.name === column)) {
    sqlite.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  }
}
ensureColumn("candidates", "resume_url", "resume_url TEXT");
ensureColumn("candidates", "external_avatar_url", "external_avatar_url TEXT");
ensureColumn("vacancies", "external_url", "external_url TEXT");
ensureColumn("messages", "source", "source TEXT");
ensureColumn("messages", "external_id", "external_id TEXT");
ensureColumn("messages", "delivery_status", "delivery_status TEXT");

export const db = drizzle(sqlite);

export interface IStorage {
  // vacancies
  getVacancies(): Promise<Vacancy[]>;
  getVacancy(id: string): Promise<Vacancy | undefined>;
  createVacancy(v: InsertVacancy): Promise<Vacancy>;
  updateVacancy(id: string, v: Partial<InsertVacancy>): Promise<Vacancy | undefined>;
  deleteVacancy(id: string): Promise<void>;
  // candidates
  getCandidates(filters?: { stage?: string; vacancyId?: string; source?: string }): Promise<Candidate[]>;
  getCandidate(id: string): Promise<Candidate | undefined>;
  createCandidate(c: InsertCandidate): Promise<Candidate>;
  updateCandidate(id: string, c: Partial<InsertCandidate>): Promise<Candidate | undefined>;
  deleteCandidate(id: string): Promise<void>;
  // documents
  getDocuments(candidateId: string): Promise<Document[]>;
  createDocument(d: InsertDocument): Promise<Document>;
  updateDocument(id: string, d: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: string): Promise<void>;
  // messages
  getMessages(candidateId: string): Promise<Message[]>;
  createMessage(m: InsertMessage): Promise<Message>;
  // activities
  getActivities(candidateId: string): Promise<Activity[]>;
  createActivity(a: InsertActivity): Promise<Activity>;
  getRecentActivities(limit: number): Promise<Activity[]>;
  // messages (extra)
  createMessageAt(m: InsertMessage, sentAt: string): Promise<Message>;
  getMessage(id: string): Promise<Message | undefined>;
  getMessageByExternal(source: string, externalId: string): Promise<Message | undefined>;
  updateMessage(id: string, m: Partial<Message>): Promise<Message | undefined>;
  // candidates (extra)
  getCandidateByPhone(phone: string): Promise<Candidate | undefined>;
  // integrations
  getIntegrations(): Promise<Integration[]>;
  getIntegration(source: string): Promise<Integration | undefined>;
  getIntegrationsByStatus(status: string): Promise<Integration[]>;
  upsertIntegration(source: string, data: Partial<InsertIntegration>): Promise<Integration>;
  updateIntegration(id: string, data: Partial<Integration>): Promise<Integration | undefined>;
  // external refs
  getExternalRef(source: string, externalType: string, externalId: string): Promise<ExternalRef | undefined>;
  getExternalRefsForEntity(entityType: string, entityId: string): Promise<ExternalRef[]>;
  getExternalRefByEntity(entityType: string, entityId: string, source: string, externalType: string): Promise<ExternalRef | undefined>;
  createExternalRef(r: InsertExternalRef): Promise<ExternalRef>;
  // oauth states
  createOauthState(state: string, source: string): Promise<OauthState>;
  getOauthState(state: string): Promise<OauthState | undefined>;
  deleteOauthState(state: string): Promise<void>;
  deleteExpiredOauthStates(beforeIso: string): Promise<number>;
  // webhook events
  createWebhookEvent(e: InsertWebhookEvent): Promise<WebhookEvent>;
  getWebhookEvent(id: string): Promise<WebhookEvent | undefined>;
  getPendingWebhookEvents(limit: number): Promise<WebhookEvent[]>;
  updateWebhookEvent(id: string, data: Partial<WebhookEvent>): Promise<WebhookEvent | undefined>;
}

export class DatabaseStorage implements IStorage {
  // ---- vacancies ----
  async getVacancies(): Promise<Vacancy[]> {
    return db.select().from(vacancies).all();
  }
  async getVacancy(id: string): Promise<Vacancy | undefined> {
    return db.select().from(vacancies).where(eq(vacancies.id, id)).get();
  }
  async createVacancy(v: InsertVacancy): Promise<Vacancy> {
    return db.insert(vacancies).values({ ...v, id: randomUUID() }).returning().get();
  }
  async updateVacancy(id: string, v: Partial<InsertVacancy>): Promise<Vacancy | undefined> {
    return db.update(vacancies).set(v).where(eq(vacancies.id, id)).returning().get();
  }
  async deleteVacancy(id: string): Promise<void> {
    db.delete(vacancies).where(eq(vacancies.id, id)).run();
  }

  // ---- candidates ----
  async getCandidates(filters?: { stage?: string; vacancyId?: string; source?: string }): Promise<Candidate[]> {
    let rows = db.select().from(candidates).orderBy(desc(candidates.createdAt)).all();
    if (filters?.stage) rows = rows.filter((r) => r.stage === filters.stage);
    if (filters?.vacancyId) rows = rows.filter((r) => r.vacancyId === filters.vacancyId);
    if (filters?.source) rows = rows.filter((r) => r.source === filters.source);
    return rows;
  }
  async getCandidate(id: string): Promise<Candidate | undefined> {
    return db.select().from(candidates).where(eq(candidates.id, id)).get();
  }
  async createCandidate(c: InsertCandidate): Promise<Candidate> {
    return db.insert(candidates).values({
      ...c, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async updateCandidate(id: string, c: Partial<InsertCandidate>): Promise<Candidate | undefined> {
    return db.update(candidates).set(c).where(eq(candidates.id, id)).returning().get();
  }
  async deleteCandidate(id: string): Promise<void> {
    db.delete(candidates).where(eq(candidates.id, id)).run();
    db.delete(messages).where(eq(messages.candidateId, id)).run();
    db.delete(documents).where(eq(documents.candidateId, id)).run();
    db.delete(activities).where(eq(activities.candidateId, id)).run();
  }

  // ---- documents ----
  async getDocuments(candidateId: string): Promise<Document[]> {
    return db.select().from(documents).where(eq(documents.candidateId, candidateId)).all();
  }
  async createDocument(d: InsertDocument): Promise<Document> {
    return db.insert(documents).values({
      ...d, id: randomUUID(), uploadedAt: new Date().toISOString(),
    }).returning().get();
  }
  async updateDocument(id: string, d: Partial<InsertDocument>): Promise<Document | undefined> {
    return db.update(documents).set(d).where(eq(documents.id, id)).returning().get();
  }
  async deleteDocument(id: string): Promise<void> {
    db.delete(documents).where(eq(documents.id, id)).run();
  }

  // ---- messages ----
  async getMessages(candidateId: string): Promise<Message[]> {
    return db.select().from(messages).where(eq(messages.candidateId, candidateId)).all();
  }
  async createMessage(m: InsertMessage): Promise<Message> {
    return db.insert(messages).values({
      ...m, id: randomUUID(), sentAt: new Date().toISOString(),
    }).returning().get();
  }

  // ---- activities ----
  async getActivities(candidateId: string): Promise<Activity[]> {
    return db.select().from(activities).where(eq(activities.candidateId, candidateId))
      .orderBy(desc(activities.createdAt)).all();
  }
  async createActivity(a: InsertActivity): Promise<Activity> {
    return db.insert(activities).values({
      ...a, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async getRecentActivities(limit: number): Promise<Activity[]> {
    return db.select().from(activities).orderBy(desc(activities.createdAt)).limit(limit).all();
  }

  // ---- messages (extra) ----
  async createMessageAt(m: InsertMessage, sentAt: string): Promise<Message> {
    return db.insert(messages).values({
      ...m, id: randomUUID(), sentAt,
    }).returning().get();
  }
  async getMessage(id: string): Promise<Message | undefined> {
    return db.select().from(messages).where(eq(messages.id, id)).get();
  }
  async getMessageByExternal(source: string, externalId: string): Promise<Message | undefined> {
    return db.select().from(messages)
      .where(and(eq(messages.source, source), eq(messages.externalId, externalId))).get();
  }
  async updateMessage(id: string, m: Partial<Message>): Promise<Message | undefined> {
    return db.update(messages).set(m).where(eq(messages.id, id)).returning().get();
  }

  // ---- candidates (extra) ----
  async getCandidateByPhone(phone: string): Promise<Candidate | undefined> {
    return db.select().from(candidates).where(eq(candidates.phone, phone)).get();
  }

  // ---- integrations ----
  async getIntegrations(): Promise<Integration[]> {
    return db.select().from(integrations).all();
  }
  async getIntegration(source: string): Promise<Integration | undefined> {
    return db.select().from(integrations).where(eq(integrations.source, source)).get();
  }
  async getIntegrationsByStatus(status: string): Promise<Integration[]> {
    return db.select().from(integrations).where(eq(integrations.status, status)).all();
  }
  async upsertIntegration(source: string, data: Partial<InsertIntegration>): Promise<Integration> {
    const now = new Date().toISOString();
    const existing = await this.getIntegration(source);
    if (existing) {
      return db.update(integrations)
        .set({ ...data, updatedAt: now })
        .where(eq(integrations.id, existing.id)).returning().get();
    }
    return db.insert(integrations).values({
      id: randomUUID(),
      source,
      status: data.status ?? "disconnected",
      accountId: data.accountId ?? null,
      accountName: data.accountName ?? null,
      accessToken: data.accessToken ?? null,
      refreshToken: data.refreshToken ?? null,
      tokenExpiresAt: data.tokenExpiresAt ?? null,
      lastSyncAt: data.lastSyncAt ?? null,
      lastError: data.lastError ?? null,
      meta: data.meta ?? null,
      createdAt: now,
      updatedAt: now,
    }).returning().get();
  }
  async updateIntegration(id: string, data: Partial<Integration>): Promise<Integration | undefined> {
    return db.update(integrations)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(integrations.id, id)).returning().get();
  }

  // ---- external refs ----
  async getExternalRef(source: string, externalType: string, externalId: string): Promise<ExternalRef | undefined> {
    return db.select().from(externalRefs).where(and(
      eq(externalRefs.source, source),
      eq(externalRefs.externalType, externalType),
      eq(externalRefs.externalId, externalId),
    )).get();
  }
  async getExternalRefsForEntity(entityType: string, entityId: string): Promise<ExternalRef[]> {
    return db.select().from(externalRefs).where(and(
      eq(externalRefs.entityType, entityType),
      eq(externalRefs.entityId, entityId),
    )).all();
  }
  async getExternalRefByEntity(entityType: string, entityId: string, source: string, externalType: string): Promise<ExternalRef | undefined> {
    return db.select().from(externalRefs).where(and(
      eq(externalRefs.entityType, entityType),
      eq(externalRefs.entityId, entityId),
      eq(externalRefs.source, source),
      eq(externalRefs.externalType, externalType),
    )).get();
  }
  async createExternalRef(r: InsertExternalRef): Promise<ExternalRef> {
    return db.insert(externalRefs).values({
      ...r, id: randomUUID(), createdAt: new Date().toISOString(),
    }).returning().get();
  }

  // ---- oauth states ----
  async createOauthState(state: string, source: string): Promise<OauthState> {
    return db.insert(oauthStates).values({
      state, source, createdAt: new Date().toISOString(),
    }).returning().get();
  }
  async getOauthState(state: string): Promise<OauthState | undefined> {
    return db.select().from(oauthStates).where(eq(oauthStates.state, state)).get();
  }
  async deleteOauthState(state: string): Promise<void> {
    db.delete(oauthStates).where(eq(oauthStates.state, state)).run();
  }
  async deleteExpiredOauthStates(beforeIso: string): Promise<number> {
    const res = db.delete(oauthStates).where(lt(oauthStates.createdAt, beforeIso)).run();
    return res.changes;
  }

  // ---- webhook events ----
  async createWebhookEvent(e: InsertWebhookEvent): Promise<WebhookEvent> {
    return db.insert(webhookEvents).values({
      ...e, id: randomUUID(), receivedAt: new Date().toISOString(),
    }).returning().get();
  }
  async getWebhookEvent(id: string): Promise<WebhookEvent | undefined> {
    return db.select().from(webhookEvents).where(eq(webhookEvents.id, id)).get();
  }
  async getPendingWebhookEvents(limit: number): Promise<WebhookEvent[]> {
    return db.select().from(webhookEvents)
      .where(eq(webhookEvents.status, "pending"))
      .orderBy(webhookEvents.receivedAt).limit(limit).all();
  }
  async updateWebhookEvent(id: string, data: Partial<WebhookEvent>): Promise<WebhookEvent | undefined> {
    return db.update(webhookEvents).set(data).where(eq(webhookEvents.id, id)).returning().get();
  }
}

export const storage = new DatabaseStorage();

// ============ SEED ============
function iso(daysAgo: number, hour = 10, min = 0): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, min, 0, 0);
  return d.toISOString();
}

export function seedDatabase() {
  const existing = db.select().from(vacancies).all();
  if (existing.length > 0) return;

  // ---- Vacancies ----
  const vacancyDefs: Vacancy[] = [
    { id: randomUUID(), title: "Мастер маникюра", city: "Москва", salary: "от 90 000 ₽", status: "active", description: "Ищем мастера маникюра и педикюра в премиальный салон в центре Москвы. График 2/2, оформление по ТК РФ, своя клиентская база приветствуется.", externalUrl: null },
    { id: randomUUID(), title: "Косметолог", city: "Санкт-Петербург", salary: "от 120 000 ₽", status: "active", description: "Косметолог-эстетист в сеть Skin Line. Аппаратная и инъекционная косметология. Медицинское образование обязательно, действующий сертификат.", externalUrl: null },
    { id: randomUUID(), title: "Администратор салона", city: "Москва", salary: "от 70 000 ₽", status: "active", description: "Администратор на ресепшн. Запись клиентов, работа с CRM, контроль кассы. Грамотная речь, опыт в индустрии красоты желателен.", externalUrl: null },
    { id: randomUUID(), title: "Массажист", city: "Казань", salary: "от 85 000 ₽", status: "paused", description: "Массажист в SPA-зону. Классический, лимфодренажный, антицеллюлитный массаж. Медкнижка обязательна.", externalUrl: null },
    { id: randomUUID(), title: "Парикмахер-стилист", city: "Санкт-Петербург", salary: "от 100 000 ₽", status: "active", description: "Парикмахер-универсал в современный салон. Стрижки, окрашивание, уходовые процедуры. Портфолио работ обязательно.", externalUrl: null },
  ];
  db.insert(vacancies).values(vacancyDefs).run();
  const [vMani, vCosm, vAdmin, vMass, vHair] = vacancyDefs;

  const tagPool = ["русский", "опытная", "своя клиентура", "без опыта", "переезд", "англ. язык", "сертификат", "медкнижка"];

  type Seed = {
    name: string; phone: string; email: string | null; city: string; vacancy: Vacancy;
    source: string; stage: string; exp: string; expected: string | null; rating: number | null;
    tags: string[]; reject?: string; notes?: string;
  };

  const seeds: Seed[] = [
    // new (4)
    { name: "Анна Иванова", phone: "+7 916 123-45-67", email: "anna.ivanova@mail.ru", city: "Москва", vacancy: vMani, source: "avito", stage: "new", exp: "5 лет", expected: "95 000 ₽", rating: null, tags: ["опытная", "своя клиентура"] },
    { name: "Екатерина Петрова", phone: "+7 921 234-56-78", email: null, city: "Санкт-Петербург", vacancy: vCosm, source: "hh", stage: "new", exp: "3 года", expected: "110 000 ₽", rating: null, tags: ["сертификат"] },
    { name: "Мария Соколова", phone: "+7 917 345-67-89", email: "m.sokolova@gmail.com", city: "Москва", vacancy: vAdmin, source: "telegram", stage: "new", exp: "2 года", expected: "70 000 ₽", rating: null, tags: ["англ. язык"] },
    { name: "Ольга Кузнецова", phone: "+7 905 456-78-90", email: null, city: "Казань", vacancy: vMass, source: "avito", stage: "new", exp: "7 лет", expected: "90 000 ₽", rating: null, tags: ["опытная", "медкнижка"] },
    // screening (3)
    { name: "Наталья Морозова", phone: "+7 926 567-89-01", email: "natalia.m@yandex.ru", city: "Санкт-Петербург", vacancy: vHair, source: "hh", stage: "screening", exp: "8 лет", expected: "120 000 ₽", rating: 4, tags: ["опытная", "своя клиентура"], notes: "Сильное портфолио, договорились о звонке." },
    { name: "Юлия Васильева", phone: "+7 903 678-90-12", email: "yulia.v@mail.ru", city: "Москва", vacancy: vMani, source: "avito", stage: "screening", exp: "4 года", expected: "85 000 ₽", rating: 4, tags: ["русский"] },
    { name: "Светлана Орлова", phone: "+7 911 789-01-23", email: null, city: "Санкт-Петербург", vacancy: vCosm, source: "telegram", stage: "screening", exp: "6 лет", expected: "130 000 ₽", rating: 5, tags: ["сертификат", "опытная"] },
    // test_service (2)
    { name: "Дарья Никитина", phone: "+7 918 890-12-34", email: "darya.nik@gmail.com", city: "Москва", vacancy: vAdmin, source: "hh", stage: "test_service", exp: "3 года", expected: "72 000 ₽", rating: 4, tags: ["англ. язык", "опытная"] },
    { name: "Алина Смирнова", phone: "+7 902 901-23-45", email: null, city: "Казань", vacancy: vMass, source: "avito", stage: "test_service", exp: "5 лет", expected: "88 000 ₽", rating: 5, tags: ["медкнижка", "опытная"] },
    // documents (2)
    { name: "Виктория Лебедева", phone: "+7 925 012-34-56", email: "v.lebedeva@yandex.ru", city: "Санкт-Петербург", vacancy: vHair, source: "hh", stage: "documents", exp: "10 лет", expected: "115 000 ₽", rating: 5, tags: ["опытная", "своя клиентура", "сертификат"], notes: "Собирает пакет документов, медкнижка в процессе." },
    { name: "Татьяна Зайцева", phone: "+7 909 123-45-67", email: "t.zaytseva@mail.ru", city: "Москва", vacancy: vMani, source: "avito", stage: "documents", exp: "6 лет", expected: "92 000 ₽", rating: 4, tags: ["опытная"] },
    // offer (1)
    { name: "Елена Попова", phone: "+7 916 234-56-78", email: "elena.popova@gmail.com", city: "Санкт-Петербург", vacancy: vCosm, source: "telegram", stage: "offer", exp: "9 лет", expected: "125 000 ₽", rating: 5, tags: ["сертификат", "опытная", "своя клиентура"], notes: "Отправлен оффер, ждём решения до конца недели." },
    // hired (2)
    { name: "Кристина Волкова", phone: "+7 921 345-67-89", email: "kristina.v@yandex.ru", city: "Москва", vacancy: vAdmin, source: "hh", stage: "hired", exp: "4 года", expected: "73 000 ₽", rating: 5, tags: ["англ. язык", "опытная"], notes: "Выходит на работу с понедельника." },
    { name: "Полина Соловьёва", phone: "+7 917 456-78-90", email: "polina.s@mail.ru", city: "Казань", vacancy: vMass, source: "avito", stage: "hired", exp: "8 лет", expected: "87 000 ₽", rating: 5, tags: ["опытная", "медкнижка"] },
    // rejected (1)
    { name: "Алёна Козлова", phone: "+7 905 567-89-01", email: null, city: "Москва", vacancy: vMani, source: "avito", stage: "rejected", exp: "1 год", expected: "80 000 ₽", rating: 2, tags: ["без опыта"], reject: "Недостаточно опыта работы для премиального сегмента." },
  ];

  const msgInbound = [
    "Здравствуйте! Видела вашу вакансию, очень заинтересована.",
    "Подскажите, какой график работы и условия?",
    "Да, у меня есть действующая медкнижка и сертификаты.",
    "Удобно созвониться завтра после 15:00?",
    "Спасибо за информацию, жду приглашение на собеседование.",
    "Готова приехать на тестовую услугу в любой день.",
  ];
  const msgOutbound = [
    "Добрый день! Спасибо за отклик. Расскажите о вашем опыте?",
    "График 2/2, оформление по ТК РФ, оклад + проценты.",
    "Отлично! Приглашаем вас на собеседование.",
    "Можете прислать портфолио ваших работ?",
    "Записали вас на тестовую услугу, ждём!",
    "Хорошего дня! Будем на связи.",
  ];

  let dayCounter = 0;
  for (const s of seeds) {
    dayCounter += 1;
    const created = iso(20 - dayCounter % 18, 9 + (dayCounter % 6));
    const cand = db.insert(candidates).values({
      id: randomUUID(),
      fullName: s.name,
      phone: s.phone,
      email: s.email,
      city: s.city,
      vacancyId: s.vacancy.id,
      source: s.source,
      sourceUrl: s.source === "avito" ? "https://www.avito.ru/moskva/rezume/master_manikyura" :
                 s.source === "hh" ? "https://hh.ru/resume/example" : null,
      stage: s.stage,
      experience: s.exp,
      expectedSalary: s.expected,
      rating: s.rating,
      notes: s.notes ?? null,
      tags: JSON.stringify(s.tags),
      rejectReason: s.reject ?? null,
      avatarUrl: null,
      createdAt: created,
    }).returning().get();

    // messages: 3-8
    const msgChannel = s.source === "telegram" ? "telegram" : s.source === "avito" ? "avito" : "telegram";
    const nMsgs = 3 + (dayCounter % 6); // 3..8
    for (let i = 0; i < nMsgs; i++) {
      const outbound = i % 2 === 1;
      db.insert(messages).values({
        id: randomUUID(),
        candidateId: cand.id,
        channel: i % 3 === 0 ? msgChannel : (i % 2 === 0 ? "avito" : "telegram"),
        direction: outbound ? "out" : "in",
        text: outbound ? msgOutbound[i % msgOutbound.length] : msgInbound[i % msgInbound.length],
        sentAt: iso(15 - dayCounter % 12, 10 + i, i * 7 % 60),
        isRead: 1,
      }).run();
    }

    // activities: 2-5
    db.insert(activities).values({
      id: randomUUID(), candidateId: cand.id, type: "stage_change",
      description: `Кандидат добавлен в воронку из источника ${s.source === "avito" ? "Avito" : s.source === "hh" ? "hh.ru" : s.source === "telegram" ? "Telegram" : "вручную"}`,
      createdAt: created, meta: null,
    }).run();
    const nAct = 1 + (dayCounter % 4); // 1..4 extra => 2..5 total
    const actTemplates = [
      { type: "message", desc: "Получено новое сообщение от кандидата" },
      { type: "call", desc: "Телефонный разговор: обсудили условия и график" },
      { type: "note", desc: "Добавлена заметка рекрутёра" },
      { type: "stage_change", desc: "Этап изменён" },
      { type: "interview_scheduled", desc: "Запланировано собеседование" },
      { type: "document_uploaded", desc: "Загружен документ кандидата" },
    ];
    for (let i = 0; i < nAct; i++) {
      const t = actTemplates[(dayCounter + i) % actTemplates.length];
      db.insert(activities).values({
        id: randomUUID(), candidateId: cand.id, type: t.type,
        description: t.desc, createdAt: iso(12 - i, 11 + i), meta: null,
      }).run();
    }
  }

  // Documents for first 4 candidates (3-4 of them with 1-3 docs)
  const docCands = db.select().from(candidates).all()
    .filter((c) => ["documents", "offer", "hired"].includes(c.stage)).slice(0, 4);
  const docTypes = ["passport", "medical_book", "snils", "inn", "diploma", "certificate"];
  const docNames: Record<string, string> = {
    passport: "Паспорт_скан.pdf", medical_book: "Медкнижка.pdf", snils: "СНИЛС.pdf",
    inn: "ИНН.pdf", diploma: "Диплом.pdf", certificate: "Сертификат.pdf",
  };
  docCands.forEach((c, idx) => {
    const count = 1 + (idx % 3); // 1..3
    for (let i = 0; i < count; i++) {
      const type = docTypes[i % docTypes.length];
      db.insert(documents).values({
        id: randomUUID(), candidateId: c.id, type,
        fileName: docNames[type], fileUrl: "https://placehold.co/600x800/326070/ffffff?text=" + encodeURIComponent(docNames[type]),
        uploadedAt: iso(5 - i, 12), verified: i === 0 ? 1 : 0,
      }).run();
    }
  });

  console.log("[seed] Database seeded with vacancies, candidates, messages, activities and documents.");
}
