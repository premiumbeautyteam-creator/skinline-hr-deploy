# Интеграция с hh.ru — Skin Line HR CRM

Документ описывает подключение, настройку и эксплуатацию интеграции с
[hh.ru API](https://api.hh.ru/openapi/redoc) в HR CRM сети салонов Skin Line.

Интеграция реализована «по-настоящему»: OAuth-авторизация работодателя,
автоматический импорт откликов (negotiations) с активных вакансий, переписка с
кандидатом прямо из карточки, фоновая синхронизация и приём webhook'ов.

---

## 1. Регистрация приложения на hh.ru

1. Войдите в аккаунт работодателя на [hh.ru](https://hh.ru).
2. Откройте [Кабинет разработчика](https://dev.hh.ru/) → **Мои приложения** →
   **Создать приложение**.
3. Заполните данные приложения:
   - **Название**: `SkinLineCRM`
   - **Redirect URI**: точный адрес коллбэка, например
     `https://hr.skinmyline.ru/api/integrations/hh/callback`
     (должен совпадать со значением `HH_REDIRECT_URI` из `.env` символ-в-символ).
4. После модерации вы получите **Client ID** и **Client Secret**.
5. Запросите у hh.ru доступ к необходимым методам (отклики, резюме,
   сообщения). Для работодательского токена нужны права на чтение
   negotiations и резюме, а также отправку сообщений в переписку.

> Все запросы к API отправляются с обязательными заголовками:
> `Authorization: Bearer {token}`,
> `HH-User-Agent: SkinLineCRM/1.0 (premium.beauty.team@gmail.com)` и
> `User-Agent` с тем же значением. Это уже зашито в `server/integrations/hh.ts`.

---

## 2. Переменные окружения (`.env`)

Создайте файл `.env` в корне проекта (он в `.gitignore`):

```dotenv
# --- hh.ru OAuth ---
HH_CLIENT_ID=ваш_client_id
HH_CLIENT_SECRET=ваш_client_secret
HH_REDIRECT_URI=https://hr.skinmyline.ru/api/integrations/hh/callback

# --- Шифрование токенов в БД (AES-256-GCM) ---
# 32 байта в hex = 64 символа. Сгенерируйте так:
#   openssl rand -hex 32
ENCRYPTION_KEY=полученные_64_hex_символа
```

Сгенерировать ключ шифрования:

```bash
openssl rand -hex 32
```

**Важно про `ENCRYPTION_KEY`:**

- Если переменная не задана, приложение в режиме разработки создаёт временный
  ключ в файле `.encryption_key` (он в `.gitignore`) и пишет предупреждение в
  лог. **На продакшене всегда задавайте `ENCRYPTION_KEY` явно** — иначе при
  потере файла токены в БД станет невозможно расшифровать.
- При смене ключа все ранее сохранённые токены станут нечитаемыми — потребуется
  переподключить аккаунт hh.ru.

Если при попытке подключения переменные не настроены, эндпоинт
`GET /api/integrations/hh/connect` вернёт `400` с сообщением:
`Не настроены переменные окружения для hh.ru. Проверьте .env.`

---

## 3. Подключение аккаунта

1. Откройте **Настройки** в CRM (`/#/settings`).
2. В карточке **hh.ru API** нажмите **«Подключить hh.ru»**.
3. Вас перенаправит на страницу авторизации hh.ru. Войдите как работодатель и
   подтвердите доступ.
4. hh.ru вернёт вас на `HH_REDIRECT_URI`. CRM обменяет код на токены, зашифрует
   и сохранит их, подтянет имя аккаунта через `GET /me` и покажет статус
   **«Подключено»**.
5. После подключения нажмите **«Синхронизировать сейчас»** или дождитесь
   автоматической синхронизации (каждые 3 минуты).

**Жизненный цикл токенов:**

- Access-токен живёт 14 дней.
- Refresh-токен **одноразовый**: при каждом обновлении hh.ru выдаёт новую пару
  токенов, старый refresh-токен сразу аннулируется. CRM сохраняет новую пару
  атомарно (см. `HhClient.refresh`).
- Фоновая задача обновляет токен заранее, если до истечения осталось < 24 часов.
- При сбое запроса с истёкшим токеном клиент один раз пытается обновить токен и
  повторить запрос автоматически.

---

## 4. Webhooks

Эндпоинт приёма событий: `POST /api/integrations/hh/webhook`.

1. Настройте подписку на webhook'и через техподдержку hh.ru: напишите на
   **api@hh.ru** с указанием URL коллбэка
   (`https://hr.skinmyline.ru/api/integrations/hh/webhook`) и нужных типов
   событий (новые отклики и сообщения в переписке).
2. CRM на каждое событие:
   - записывает его в таблицу `webhook_events` со статусом `pending`;
   - немедленно отвечает `200 OK` (чтобы hh.ru не делал повторные доставки);
   - асинхронно обрабатывает событие — импортирует отклик/сообщения.

> **Замечание о формате.** Точный формат payload'а и схема подписи webhook'ов
> hh.ru публично не задокументированы. Код написан защитно: он ищет
> `negotiation_id` в нескольких возможных местах payload'а и логирует
> неизвестные структуры. Заголовок подписи (`X-Hh-Signature`) логируется; при
> отсутствии пишется предупреждение. В коде оставлены `TODO`-комментарии
> (`server/routes.ts`, `server/integrations/hh-ingest.ts`) — после уточнения
> формата у hh.ru останется только включить проверку подписи и поправить
> парсинг полей.

**Polling fallback.** Даже если webhook'и не настроены или событие потеряно,
фоновая задача каждые 3 минуты вызывает `pollAll()` и подтягивает новые отклики
с активных вакансий. Импорт идемпотентен (дедупликация по `external_refs` и по
нормализованному телефону), поэтому дубликаты кандидатов не создаются.

---

## 5. Деплой на VPS (Timeweb)

Целевое окружение: Ubuntu 24.04 + Node.js 20. Прототип использует SQLite;
миграция на PostgreSQL сводится к замене драйвера Drizzle (см. раздел 7).

```bash
# 1. Установить зависимости и собрать
npm ci
npm run build

# 2. Прописать переменные окружения (см. раздел 2) в .env или в systemd-юните

# 3. Запустить продакшен-сборку
NODE_ENV=production node dist/index.cjs
```

Рекомендуется обернуть процесс в **systemd** (или PM2) и поставить **nginx** как
reverse-proxy с TLS (Let's Encrypt). Пример systemd-юнита:

```ini
[Unit]
Description=Skin Line HR CRM
After=network.target

[Service]
WorkingDirectory=/opt/skinline-hr-crm
EnvironmentFile=/opt/skinline-hr-crm/.env
ExecStart=/usr/bin/node dist/index.cjs
Environment=NODE_ENV=production
Restart=always
User=www-data

[Install]
WantedBy=multi-user.target
```

nginx должен проксировать `https://hr.skinmyline.ru` → `http://127.0.0.1:5000`
и обязательно пропускать пути `/api/integrations/hh/callback` и
`/api/integrations/hh/webhook`.

---

## 6. Фоновые задачи (scheduler)

Реализованы в `server/jobs/scheduler.ts` на `node-cron`, запускаются при старте
сервера:

| Задача                       | Периодичность | Назначение                                          |
| ---------------------------- | ------------- | --------------------------------------------------- |
| Импорт откликов (`pollAll`)  | каждые 3 мин  | Polling-fallback к webhook'ам                       |
| Очистка `oauth_states`       | каждые 10 мин | Удаление просроченных OAuth-state                   |
| Обновление токенов           | каждые 60 мин | Refresh, если до истечения < 24 ч                   |
| Обработка `webhook_events`   | каждые 30 сек | Дообработка отложенных/упавших событий (до 10 шт.)  |

Каждая задача обёрнута в try/catch — сбой одной не роняет процесс и не
останавливает планировщик.

---

## 7. Диагностика

**Логи.** Все сообщения интеграции имеют префиксы `[hh]`, `[scheduler]`,
`[poll-hh]` и т.п. Смотрите логи процесса:

```bash
journalctl -u skinline-hr-crm -f          # при systemd
# или просто stdout/stderr процесса node
```

**Проверка эндпоинтов (curl):**

```bash
# Список интеграций (токены всегда замаскированы)
curl -s http://127.0.0.1:5000/api/integrations | jq

# Статус только hh.ru
curl -s http://127.0.0.1:5000/api/integrations/hh | jq

# Запуск ручной синхронизации (нужен подключённый аккаунт)
curl -s -X POST http://127.0.0.1:5000/api/integrations/hh/sync | jq
# Ответ: { ok, ingestedCount, createdCount, imported }
```

**Таблица webhook_events.** Хранит входящие события и их статус
(`pending | processed | failed`), число попыток и последнюю ошибку:

```sql
SELECT id, event_type, status, attempts, last_error, received_at, processed_at
FROM webhook_events
ORDER BY received_at DESC
LIMIT 20;
```

**Связи с внешними сущностями.** Таблица `external_refs` связывает кандидатов и
вакансии с объектами hh.ru (negotiation, resume) и обеспечивает идемпотентность
импорта:

```sql
SELECT entity_type, entity_id, source, external_type, external_id
FROM external_refs WHERE source = 'hh';
```

**Безопасность токенов.** Токены хранятся в таблице `integrations` в
зашифрованном виде (AES-256-GCM, формат `iv:tag:data` в base64) и **никогда не
возвращаются в API** — ответы используют тип `IntegrationPublic` с полем
`hasTokens: boolean` вместо самих токенов.

---

## 8. Миграция на PostgreSQL (на будущее)

Прототип использует `better-sqlite3`. Для перехода на PostgreSQL:

1. Заменить драйвер в `drizzle.config.ts` и в инициализации БД на
   `drizzle-orm/node-postgres` (или `postgres-js`).
2. Схема в `shared/schema.ts` переписывается с `sqliteTable` на `pgTable`
   (типы колонок: `text`, `timestamp`, `integer`, `boolean`).
3. SQL-запросы через query builder Drizzle остаются без изменений.
4. Прогнать миграции Drizzle Kit против PostgreSQL.

Логика интеграции (`server/integrations/*`, `server/jobs/*`) от драйвера БД не
зависит и переноса не требует.
