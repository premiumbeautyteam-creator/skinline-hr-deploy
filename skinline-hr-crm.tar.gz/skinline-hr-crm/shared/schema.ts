import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Vacancies
export const vacancies = sqliteTable("vacancies", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  city: text("city").notNull(),
  salary: text("salary").notNull(),
  status: text("status").notNull(), // active | paused | closed
  description: text("description").notNull(),
  externalUrl: text("external_url"), // link to vacancy on source (hh/avito)
});

export const insertVacancySchema = createInsertSchema(vacancies).omit({ id: true });
export type InsertVacancy = z.infer<typeof insertVacancySchema>;
export type Vacancy = typeof vacancies.$inferSelect;

// Candidates
export const candidates = sqliteTable("candidates", {
  id: text("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  city: text("city").notNull(),
  vacancyId: text("vacancy_id").notNull(),
  source: text("source").notNull(), // avito | hh | manual | telegram
  sourceUrl: text("source_url"),
  stage: text("stage").notNull(), // new | screening | test_service | documents | offer | hired | rejected
  experience: text("experience").notNull(),
  expectedSalary: text("expected_salary"),
  rating: integer("rating"), // 1-5
  notes: text("notes"),
  tags: text("tags").notNull().default("[]"), // JSON array stored as text
  rejectReason: text("reject_reason"),
  avatarUrl: text("avatar_url"),
  resumeUrl: text("resume_url"), // link back to hh resume / avito profile
  externalAvatarUrl: text("external_avatar_url"), // avatar copied from source
  createdAt: text("created_at").notNull(),
});

export const insertCandidateSchema = createInsertSchema(candidates).omit({ id: true, createdAt: true });
export type InsertCandidate = z.infer<typeof insertCandidateSchema>;
export type Candidate = typeof candidates.$inferSelect;

// Documents
export const documents = sqliteTable("documents", {
  id: text("id").primaryKey(),
  candidateId: text("candidate_id").notNull(),
  type: text("type").notNull(), // passport | medical_book | snils | inn | diploma | certificate | other
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  uploadedAt: text("uploaded_at").notNull(),
  verified: integer("verified").notNull().default(0),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, uploadedAt: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// Messages
export const messages = sqliteTable("messages", {
  id: text("id").primaryKey(),
  candidateId: text("candidate_id").notNull(),
  channel: text("channel").notNull(), // hh | avito | telegram | whatsapp | internal
  direction: text("direction").notNull(), // in | out
  text: text("text").notNull(),
  sentAt: text("sent_at").notNull(),
  isRead: integer("is_read").notNull().default(0),
  source: text("source"), // hh | avito | null (internal). Used together with externalId for dedupe.
  externalId: text("external_id"), // source-side message id (unique with source) for idempotent ingest
  deliveryStatus: text("delivery_status"), // pending | delivered | failed | local | null
});

export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, sentAt: true });
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Activities
export const activities = sqliteTable("activities", {
  id: text("id").primaryKey(),
  candidateId: text("candidate_id").notNull(),
  type: text("type").notNull(), // stage_change | note | call | message | document_uploaded | interview_scheduled
  description: text("description").notNull(),
  createdAt: text("created_at").notNull(),
  meta: text("meta"), // JSON nullable
});

export const insertActivitySchema = createInsertSchema(activities).omit({ id: true, createdAt: true });
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// ============================================================================
// Integration tables (hh.ru / avito / telegram)
// ============================================================================

// integrations: one row per connected source account
export const integrations = sqliteTable("integrations", {
  id: text("id").primaryKey(),
  source: text("source").notNull(), // hh | avito | telegram
  status: text("status").notNull(), // disconnected | connected | error | refreshing
  accountId: text("account_id"), // hh employer_id, avito user_id
  accountName: text("account_name"), // display name from API
  accessToken: text("access_token"), // encrypted (iv:tag:data base64)
  refreshToken: text("refresh_token"), // encrypted
  tokenExpiresAt: text("token_expires_at"), // ISO date
  lastSyncAt: text("last_sync_at"), // ISO date
  lastError: text("last_error"),
  meta: text("meta"), // JSON — source-specific extra data (e.g. manager_id for hh)
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const insertIntegrationSchema = createInsertSchema(integrations).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;
export type Integration = typeof integrations.$inferSelect;

// Public-facing integration shape with tokens masked. Used in API responses.
export type IntegrationPublic = Omit<Integration, "accessToken" | "refreshToken"> & {
  hasTokens: boolean;
};

// external_refs: link our internal entities to source-side IDs
export const externalRefs = sqliteTable("external_refs", {
  id: text("id").primaryKey(),
  entityType: text("entity_type").notNull(), // candidate | vacancy | message
  entityId: text("entity_id").notNull(), // our internal id
  source: text("source").notNull(), // hh | avito
  externalId: text("external_id").notNull(), // hh negotiation_id / resume_id / vacancy_id ...
  externalType: text("external_type").notNull(), // negotiation | resume | vacancy | chat | item
  meta: text("meta"), // JSON nullable — extra fields like resume_url, last_message_id
  createdAt: text("created_at").notNull(),
});

export const insertExternalRefSchema = createInsertSchema(externalRefs).omit({ id: true, createdAt: true });
export type InsertExternalRef = z.infer<typeof insertExternalRefSchema>;
export type ExternalRef = typeof externalRefs.$inferSelect;

// oauth_states: CSRF protection for the OAuth flow (auto-expire after 10 min)
export const oauthStates = sqliteTable("oauth_states", {
  state: text("state").primaryKey(),
  source: text("source").notNull(),
  createdAt: text("created_at").notNull(),
});

export const insertOauthStateSchema = createInsertSchema(oauthStates).omit({ createdAt: true });
export type InsertOauthState = z.infer<typeof insertOauthStateSchema>;
export type OauthState = typeof oauthStates.$inferSelect;

// webhook_events: idempotency + replay for inbound webhooks
export const webhookEvents = sqliteTable("webhook_events", {
  id: text("id").primaryKey(),
  source: text("source").notNull(),
  eventType: text("event_type").notNull(),
  externalId: text("external_id"),
  payload: text("payload").notNull(), // JSON
  status: text("status").notNull(), // pending | processed | failed
  attempts: integer("attempts").notNull().default(0),
  lastError: text("last_error"),
  receivedAt: text("received_at").notNull(),
  processedAt: text("processed_at"),
});

export const insertWebhookEventSchema = createInsertSchema(webhookEvents).omit({ id: true, receivedAt: true });
export type InsertWebhookEvent = z.infer<typeof insertWebhookEventSchema>;
export type WebhookEvent = typeof webhookEvents.$inferSelect;
