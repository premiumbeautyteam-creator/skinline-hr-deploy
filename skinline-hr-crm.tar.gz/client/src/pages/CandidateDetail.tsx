import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation, Link } from "wouter";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import {
  ArrowLeft, Phone, Mail, MapPin, Star, Copy, Send, Upload, Trash2, Check,
  MessageSquare, FileText, StickyNote, History, CalendarPlus, PhoneCall, Archive, X, Plus,
  AlertTriangle, Clock, CheckSquare, Bot, Link2, QrCode, Zap,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { CandidateAvatar, SourceBadge, StageBadge } from "@/components/shared";
import { STAGES, STAGE_MAP, DOC_TYPES, CHANNELS, parseTags } from "@/lib/crm";
import { cn } from "@/lib/utils";
import type { Candidate, Vacancy, Message, Activity, Document } from "@shared/schema";

// Extra types for new features
interface Task {
  id: string;
  candidateId: string;
  assigneeId: string;
  title: string;
  description: string;
  dueAt: string;
  status: "open" | "done" | "cancelled";
  createdAt: string;
  completedAt: string | null;
  source: "auto" | "manual";
  triggerStage: string | null;
}

interface ScheduledAction {
  id: string;
  candidateId: string;
  kind: string;
  runAt: string;
  payload: string;
  status: "pending" | "done" | "cancelled" | "failed";
  triggerStage: string;
  createdAt: string;
  executedAt: string | null;
  lastError: string | null;
}

interface StageEvent {
  id: string;
  candidateId: string;
  fromStage: string | null;
  toStage: string;
  changedBy: string;
  changedAt: string;
  meta: string | null;
}

interface CrmUser {
  id: string;
  name: string;
  roleKey: string;
  telegramUsername: string | null;
}

interface LinkTokenResponse {
  token: string;
  deepLink: string;
  botUsername: string;
}

function fmtDate(iso: string, withTime = false) {
  try {
    return format(new Date(iso), withTime ? "d MMM yyyy, HH:mm" : "d MMMM yyyy", { locale: ru });
  } catch { return iso; }
}

const ACTIVITY_ICONS: Record<string, React.ElementType> = {
  stage_change: History, note: StickyNote, call: PhoneCall,
  message: MessageSquare, document_uploaded: FileText, interview_scheduled: CalendarPlus,
};

export default function CandidateDetail() {
  const [, params] = useRoute("/candidates/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const id = params?.id ?? "";
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploadType, setUploadType] = useState<string>("passport");
  const [msgText, setMsgText] = useState("");
  const [msgChannel, setMsgChannel] = useState("telegram");
  const [channelTouched, setChannelTouched] = useState(false);
  const [msgFilter, setMsgFilter] = useState("all");
  const [notesDraft, setNotesDraft] = useState<string | null>(null);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [newTag, setNewTag] = useState("");
  const [newTaskOpen, setNewTaskOpen] = useState(false);
  const [newTask, setNewTask] = useState({ assigneeId: "", title: "", description: "", dueAt: "" });

  const { data: candidate, isLoading } = useQuery<Candidate>({ queryKey: ["/api/candidates", id] });

  useEffect(() => {
    if (candidate?.source === "hh" && !channelTouched) {
      setMsgChannel("hh");
    }
  }, [candidate?.source, channelTouched]);

  const { data: vacancies } = useQuery<Vacancy[]>({ queryKey: ["/api/vacancies"] });
  const { data: messages } = useQuery<Message[]>({ queryKey: ["/api/candidates", id, "messages"] });
  const { data: activities } = useQuery<Activity[]>({ queryKey: ["/api/candidates", id, "activities"] });
  const { data: documents } = useQuery<Document[]>({ queryKey: ["/api/candidates", id, "documents"] });
  const { data: tasks, refetch: refetchTasks } = useQuery<Task[]>({ queryKey: ["/api/candidates", id, "tasks"] });
  const { data: automations } = useQuery<ScheduledAction[]>({ queryKey: ["/api/candidates", id, "automations"] });
  const { data: stageEvents } = useQuery<StageEvent[]>({ queryKey: ["/api/candidates", id, "stage-events"] });
  const { data: crmUsers } = useQuery<CrmUser[]>({ queryKey: ["/api/users"] });

  if (isLoading || !candidate) {
    return <Layout title="Кандидат"><div className="p-8"><Skeleton className="h-96 w-full rounded-xl" /></div></Layout>;
  }

  const vacancy = vacancies?.find((v) => v.id === candidate.vacancyId);
  const tags = parseTags(candidate.tags);

  function invalidate() {
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id] });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates"] });
  }

  async function patchCandidate(patch: Partial<Candidate>) {
    await apiRequest("PATCH", `/api/candidates/${id}`, patch);
    invalidate();
  }

  async function copyPhone() {
    try {
      await navigator.clipboard.writeText(candidate!.phone);
      toast({ title: "Скопировано", description: candidate!.phone });
    } catch {
      toast({ title: candidate!.phone });
    }
  }

  async function setRating(r: number) {
    await patchCandidate({ rating: r });
    toast({ title: "Оценка обновлена" });
  }

  async function addTag() {
    if (!newTag.trim()) return;
    const next = [...tags, newTag.trim()];
    await patchCandidate({ tags: JSON.stringify(next) });
    setNewTag("");
  }
  async function removeTag(t: string) {
    await patchCandidate({ tags: JSON.stringify(tags.filter((x) => x !== t)) });
  }

  async function saveNotes() {
    if (notesDraft === null || notesDraft === (candidate!.notes ?? "")) return;
    await patchCandidate({ notes: notesDraft });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "activities"] });
    toast({ title: "Заметка сохранена" });
  }

  async function changeStage(stage: string, reason?: string) {
    await apiRequest("PATCH", `/api/candidates/${id}/stage`, { stage, ...(reason ? { rejectReason: reason } : {}) });
    invalidate();
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "activities"] });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "stage-events"] });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "automations"] });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "tasks"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
  }

  async function sendMessage() {
    if (!msgText.trim()) return;
    await apiRequest("POST", `/api/candidates/${id}/messages`, { channel: msgChannel, text: msgText, isRead: 1 });
    setMsgText("");
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "messages"] });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "activities"] });
  }

  async function uploadDoc(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    await apiRequest("POST", `/api/candidates/${id}/documents`, {
      type: uploadType,
      fileName: file.name,
      fileUrl: "https://placehold.co/600x800/326070/ffffff?text=" + encodeURIComponent(file.name),
      verified: 0,
    });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "documents"] });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "activities"] });
    toast({ title: "Документ загружен", description: file.name });
    if (fileRef.current) fileRef.current.value = "";
  }

  async function toggleVerify(doc: Document) {
    await apiRequest("PATCH", `/api/documents/${doc.id}`, { verified: doc.verified ? 0 : 1 });
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "documents"] });
  }
  async function deleteDoc(docId: string) {
    await apiRequest("DELETE", `/api/documents/${docId}`);
    queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "documents"] });
  }

  async function toggleTask(task: Task) {
    const newStatus = task.status === "done" ? "open" : "done";
    await apiRequest("PATCH", `/api/tasks/${task.id}`, { status: newStatus });
    refetchTasks();
  }

  async function createTask() {
    if (!newTask.title || !newTask.assigneeId || !newTask.dueAt) {
      toast({ title: "Заполните все обязательные поля", variant: "destructive" });
      return;
    }
    await apiRequest("POST", `/api/candidates/${id}/tasks`, newTask);
    setNewTaskOpen(false);
    setNewTask({ assigneeId: "", title: "", description: "", dueAt: "" });
    refetchTasks();
    toast({ title: "Задача создана" });
  }

  async function generateLinkToken() {
    try {
      const res = await apiRequest("POST", `/api/candidates/${id}/link-token`, {});
      const data = (await res.json()) as LinkTokenResponse;
      return data;
    } catch {
      return null;
    }
  }

  const filteredMsgs = (messages ?? []).filter((m) => msgFilter === "all" || m.channel === msgFilter);
  const notesValue = notesDraft ?? candidate.notes ?? "";
  const hasTelegramLink = Boolean(candidate.telegramChatId);

  return (
    <Layout title="Карточка кандидата">
      <div className="p-5 md:p-8">
        <Link href="/candidates" className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground" data-testid="link-back">
          <ArrowLeft className="h-4 w-4" /> К кандидатам
        </Link>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-4">
          {/* LEFT */}
          <Card className="p-5 lg:col-span-1">
            <div className="flex flex-col items-center text-center">
              <CandidateAvatar name={candidate.fullName} url={candidate.avatarUrl} size="xl" />
              <h2 className="mt-3 font-sans text-lg font-bold normal-case tracking-tight" style={{ letterSpacing: "-0.01em" }} data-testid="text-candidate-name">{candidate.fullName}</h2>
              <div className="mt-1 flex items-center gap-2">
                <SourceBadge source={candidate.source} />
                {vacancy && <span className="text-xs text-muted-foreground">{vacancy.title}</span>}
              </div>
            </div>

            <div className="mt-5 space-y-3 text-sm">
              <button onClick={copyPhone} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 hover-elevate" data-testid="button-copy-phone">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <span>{candidate.phone}</span>
                <Copy className="ml-auto h-3.5 w-3.5 text-muted-foreground" />
              </button>
              {candidate.email && (
                <div className="flex items-center gap-2 px-2"><Mail className="h-4 w-4 text-muted-foreground" /><span className="truncate">{candidate.email}</span></div>
              )}
              <div className="flex items-center gap-2 px-2"><MapPin className="h-4 w-4 text-muted-foreground" /><span>{candidate.city}</span></div>
            </div>

            {/* Telegram link status */}
            <div className="mt-4 rounded-lg border border-border p-3">
              <div className="mb-2 flex items-center gap-2">
                <Bot className="h-4 w-4 text-[#0088CC]" />
                <span className="marshall-display text-xs text-muted-foreground">Telegram-связка</span>
              </div>
              {hasTelegramLink ? (
                <div className="space-y-1 text-xs">
                  <div className="flex items-center gap-1 text-green-600"><Check className="h-3.5 w-3.5" /> Привязан</div>
                  <div className="text-muted-foreground">chat_id: {candidate.telegramChatId}</div>
                </div>
              ) : (
                <TelegramLinkPanel candidateId={id} />
              )}
            </div>

            {/* Rating */}
            <div className="mt-5">
              <div className="marshall-display mb-1.5 text-xs text-muted-foreground">Оценка</div>
              <div className="flex gap-1" data-testid="rating-stars">
                {[1, 2, 3, 4, 5].map((r) => (
                  <button key={r} onClick={() => setRating(r)} data-testid={`star-${r}`}>
                    <Star className={cn("h-5 w-5", (candidate.rating ?? 0) >= r ? "fill-accent text-accent" : "text-muted-foreground/40")} />
                  </button>
                ))}
              </div>
            </div>

            {/* Tags */}
            <div className="mt-5">
              <div className="marshall-display mb-1.5 text-xs text-muted-foreground">Теги</div>
              <div className="flex flex-wrap gap-1.5">
                {tags.map((t) => (
                  <span key={t} className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-xs">
                    {t}
                    <button onClick={() => removeTag(t)} data-testid={`remove-tag-${t}`}><X className="h-3 w-3 text-muted-foreground hover:text-destructive" /></button>
                  </span>
                ))}
              </div>
              <div className="mt-2 flex gap-1.5">
                <Input value={newTag} onChange={(e) => setNewTag(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addTag()} placeholder="Добавить тег" className="h-8 text-xs" data-testid="input-new-tag" />
                <Button size="icon" variant="outline" className="h-8 w-8 shrink-0" onClick={addTag} data-testid="button-add-tag"><Plus className="h-4 w-4" /></Button>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3 border-t border-border pt-4 text-sm">
              <div><div className="marshall-display text-[11px] text-muted-foreground">Опыт</div><div className="font-medium">{candidate.experience}</div></div>
              <div><div className="marshall-display text-[11px] text-muted-foreground">Ожидания</div><div className="font-medium">{candidate.expectedSalary ?? "—"}</div></div>
            </div>
          </Card>

          {/* CENTER */}
          <Card className="p-0 lg:col-span-2">
            <Tabs defaultValue="messages" className="flex h-full flex-col">
              <TabsList className="m-3 grid w-auto grid-cols-6">
                <TabsTrigger value="messages" className="marshall-display text-[10px]" data-testid="tab-messages"><MessageSquare className="mr-1 h-3.5 w-3.5" />Переписка</TabsTrigger>
                <TabsTrigger value="documents" className="marshall-display text-[10px]" data-testid="tab-documents"><FileText className="mr-1 h-3.5 w-3.5" />Документы</TabsTrigger>
                <TabsTrigger value="tasks" className="marshall-display text-[10px]" data-testid="tab-tasks"><CheckSquare className="mr-1 h-3.5 w-3.5" />Задачи</TabsTrigger>
                <TabsTrigger value="automations" className="marshall-display text-[10px]" data-testid="tab-automations"><Zap className="mr-1 h-3.5 w-3.5" />Авто</TabsTrigger>
                <TabsTrigger value="notes" className="marshall-display text-[10px]" data-testid="tab-notes"><StickyNote className="mr-1 h-3.5 w-3.5" />Заметки</TabsTrigger>
                <TabsTrigger value="history" className="marshall-display text-[10px]" data-testid="tab-history"><History className="mr-1 h-3.5 w-3.5" />История</TabsTrigger>
              </TabsList>

              {/* Messages */}
              <TabsContent value="messages" className="m-0 flex flex-1 flex-col">
                <div className="flex items-center gap-2 border-y border-border px-4 py-2">
                  <Select value={msgFilter} onValueChange={setMsgFilter}>
                    <SelectTrigger className="h-8 w-40 text-xs" data-testid="filter-channel"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все каналы</SelectItem>
                      <SelectItem value="hh">hh.ru</SelectItem>
                      <SelectItem value="avito">Avito</SelectItem>
                      <SelectItem value="telegram">Telegram</SelectItem>
                      <SelectItem value="telegram_bot">Бот Telegram</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <TooltipProvider>
                <div className="flex-1 space-y-3 overflow-auto p-4" style={{ maxHeight: 420 }} data-testid="messages-list">
                  {filteredMsgs.length === 0 && <div className="py-10 text-center text-sm text-muted-foreground">Нет сообщений</div>}
                  {filteredMsgs.map((m) => (
                    <div key={m.id} className={cn("flex", m.direction === "out" ? "justify-end" : "justify-start")}>
                      <div className={cn(
                        "max-w-[75%] rounded-xl px-3 py-2 text-sm",
                        m.direction === "out" ? "bg-primary text-primary-foreground" : "bg-muted",
                      )}>
                        <div className="mb-0.5 flex items-center gap-1 text-[10px] opacity-70">
                          {m.channel === "hh" && (
                            <span className="inline-flex items-center rounded bg-[#D6001C] px-1 py-px text-[9px] font-semibold text-white opacity-100" data-testid={`badge-hh-${m.id}`}>hh.ru</span>
                          )}
                          {m.channel === "telegram_bot" && (
                            <span className="inline-flex items-center rounded bg-[#0088CC] px-1 py-px text-[9px] font-semibold text-white opacity-100">бот</span>
                          )}
                          <span>{CHANNELS[m.channel] ?? m.channel} · {fmtDate(m.sentAt, true)}</span>
                          {m.direction === "out" && m.deliveryStatus === "failed" && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span data-testid={`status-failed-${m.id}`}><AlertTriangle className="h-3 w-3 text-red-300" /></span>
                              </TooltipTrigger>
                              <TooltipContent>Не доставлено</TooltipContent>
                            </Tooltip>
                          )}
                          {m.direction === "out" && m.deliveryStatus === "pending" && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span data-testid={`status-pending-${m.id}`}><Clock className="h-3 w-3" /></span>
                              </TooltipTrigger>
                              <TooltipContent>Отправляется…</TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                        <div>{m.text}</div>
                      </div>
                    </div>
                  ))}
                </div>
                </TooltipProvider>
                <div className="flex items-center gap-2 border-t border-border p-3">
                  <Select value={msgChannel} onValueChange={(v) => { setChannelTouched(true); setMsgChannel(v); }}>
                    <SelectTrigger className="h-9 w-32 text-xs" data-testid="select-msg-channel"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hh">hh.ru</SelectItem>
                      <SelectItem value="telegram">Telegram</SelectItem>
                      <SelectItem value="telegram_bot">Бот</SelectItem>
                      <SelectItem value="avito">Avito</SelectItem>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input value={msgText} onChange={(e) => setMsgText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && sendMessage()} placeholder="Введите сообщение..." data-testid="input-message" />
                  <Button size="icon" onClick={sendMessage} data-testid="button-send-message"><Send className="h-4 w-4" /></Button>
                </div>
              </TabsContent>

              {/* Documents */}
              <TabsContent value="documents" className="m-0 p-4">
                <input ref={fileRef} type="file" className="hidden" onChange={uploadDoc} data-testid="input-file" />
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {DOC_TYPES.map((dt) => {
                    const docs = (documents ?? []).filter((d) => d.type === dt.key);
                    return (
                      <div key={dt.key} className="rounded-xl border border-card-border p-3">
                        <div className="mb-2 flex items-center justify-between">
                          <span className="marshall-display text-xs">{dt.label}</span>
                          <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => { setUploadType(dt.key); fileRef.current?.click(); }} data-testid={`upload-${dt.key}`}>
                            <Upload className="h-3 w-3" /> Загрузить
                          </Button>
                        </div>
                        {docs.length === 0 ? (
                          <div className="text-xs text-muted-foreground">Не загружено</div>
                        ) : (
                          <div className="space-y-1.5">
                            {docs.map((d) => (
                              <div key={d.id} className="flex items-center gap-2 rounded-lg bg-muted/60 px-2 py-1.5 text-xs">
                                <FileText className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="truncate flex-1">{d.fileName}</span>
                                <button onClick={() => toggleVerify(d)} title="Проверен" data-testid={`verify-${d.id}`} className={cn("rounded p-0.5", d.verified ? "text-green-600" : "text-muted-foreground")}>
                                  <Check className="h-3.5 w-3.5" />
                                </button>
                                <button onClick={() => deleteDoc(d.id)} data-testid={`delete-doc-${d.id}`} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </TabsContent>

              {/* Tasks */}
              <TabsContent value="tasks" className="m-0 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-sm font-medium">Задачи</span>
                  <Button size="sm" className="h-7 gap-1 text-xs" onClick={() => setNewTaskOpen(true)} data-testid="button-new-task">
                    <Plus className="h-3 w-3" /> Новая задача
                  </Button>
                </div>
                <div className="space-y-2" data-testid="tasks-list">
                  {(tasks ?? []).length === 0 && <div className="py-6 text-center text-sm text-muted-foreground">Нет задач</div>}
                  {(tasks ?? []).map((task) => (
                    <div key={task.id} className={cn("rounded-xl border border-card-border p-3", task.status === "done" && "opacity-60")}>
                      <div className="flex items-start gap-2">
                        <button
                          onClick={() => toggleTask(task)}
                          data-testid={`task-toggle-${task.id}`}
                          className={cn("mt-0.5 shrink-0 rounded p-0.5", task.status === "done" ? "text-green-600" : "text-muted-foreground")}
                        >
                          <Check className="h-4 w-4" />
                        </button>
                        <div className="flex-1 min-w-0">
                          <div className={cn("text-sm font-medium", task.status === "done" && "line-through")}>{task.title}</div>
                          {task.description && <div className="mt-0.5 text-xs text-muted-foreground line-clamp-2">{task.description}</div>}
                          <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span>До {fmtDate(task.dueAt, true)}</span>
                            {task.source === "auto" && (
                              <span className="rounded-full bg-blue-100 px-1.5 py-0.5 text-[10px] text-blue-600 dark:bg-blue-500/20 dark:text-blue-300">авто</span>
                            )}
                          </div>
                        </div>
                        <span className={cn(
                          "shrink-0 rounded-full px-2 py-0.5 text-[10px]",
                          task.status === "open" ? "bg-amber-100 text-amber-700" :
                          task.status === "done" ? "bg-green-100 text-green-700" :
                          "bg-gray-100 text-gray-500"
                        )}>
                          {task.status === "open" ? "Открыта" : task.status === "done" ? "Выполнена" : "Отменена"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>

              {/* Automations */}
              <TabsContent value="automations" className="m-0 p-4">
                <div className="mb-3 text-sm font-medium">Автоматизации</div>
                <div className="space-y-3">
                  {/* Pending scheduled actions */}
                  <div>
                    <div className="marshall-display mb-2 text-xs text-muted-foreground">Запланированные действия</div>
                    {(automations ?? []).length === 0 && (
                      <div className="text-xs text-muted-foreground">Нет активных таймеров</div>
                    )}
                    {(automations ?? []).map((a) => (
                      <div key={a.id} className={cn(
                        "mb-2 rounded-lg border border-card-border p-2.5 text-xs",
                        a.status === "pending" ? "border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950/20" :
                        a.status === "done" ? "opacity-50" : "opacity-40"
                      )}>
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{a.kind}</span>
                          <span className={cn(
                            "rounded-full px-1.5 py-0.5 text-[10px]",
                            a.status === "pending" ? "bg-blue-100 text-blue-600" :
                            a.status === "done" ? "bg-green-100 text-green-600" :
                            a.status === "cancelled" ? "bg-gray-100 text-gray-500" :
                            "bg-red-100 text-red-600"
                          )}>{a.status}</span>
                        </div>
                        <div className="mt-1 text-muted-foreground">
                          <span>Запускается: {fmtDate(a.runAt, true)}</span>
                          <span className="ml-2">· Этап: {a.triggerStage}</span>
                        </div>
                        {a.lastError && <div className="mt-1 text-red-500">{a.lastError}</div>}
                      </div>
                    ))}
                  </div>

                  {/* Stage history */}
                  <div>
                    <div className="marshall-display mb-2 text-xs text-muted-foreground">История стадий</div>
                    {(stageEvents ?? []).length === 0 && (
                      <div className="text-xs text-muted-foreground">Нет событий</div>
                    )}
                    {(stageEvents ?? []).map((e) => (
                      <div key={e.id} className="mb-2 flex items-center gap-2 text-xs">
                        <div className="h-2 w-2 shrink-0 rounded-full bg-primary" />
                        <span className="text-muted-foreground">{fmtDate(e.changedAt, true)}</span>
                        <span>{e.fromStage ?? "—"} → <strong>{e.toStage}</strong></span>
                        <span className="text-muted-foreground">({e.changedBy})</span>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Notes */}
              <TabsContent value="notes" className="m-0 p-4">
                <Textarea
                  value={notesValue}
                  onChange={(e) => setNotesDraft(e.target.value)}
                  onBlur={saveNotes}
                  placeholder="Заметки рекрутёра... (сохраняется автоматически)"
                  className="min-h-[300px] resize-none"
                  data-testid="textarea-notes"
                />
              </TabsContent>

              {/* History */}
              <TabsContent value="history" className="m-0 p-4">
                <div className="space-y-0" data-testid="timeline">
                  {(activities ?? []).map((a, i) => {
                    const Icon = ACTIVITY_ICONS[a.type] ?? History;
                    return (
                      <div key={a.id} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary/40 text-primary">
                            <Icon className="h-4 w-4" />
                          </div>
                          {i < (activities?.length ?? 0) - 1 && <div className="w-px flex-1 bg-border" />}
                        </div>
                        <div className="pb-5">
                          <div className="text-sm">{a.description}</div>
                          <div className="text-xs text-muted-foreground">{fmtDate(a.createdAt, true)}</div>
                        </div>
                      </div>
                    );
                  })}
                  {(activities ?? []).length === 0 && <div className="text-sm text-muted-foreground">Нет событий</div>}
                </div>
              </TabsContent>
            </Tabs>
          </Card>

          {/* RIGHT */}
          <Card className="p-5 lg:col-span-1">
            <div className="marshall-display text-xs text-muted-foreground">Текущий этап</div>
            <div className="mt-2"><StageBadge stage={candidate.stage} /></div>
            <Select value={candidate.stage} onValueChange={(v) => changeStage(v)}>
              <SelectTrigger className="mt-3" data-testid="select-stage"><SelectValue /></SelectTrigger>
              <SelectContent>
                {STAGES.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>

            {candidate.stage === "rejected" && candidate.rejectReason && (
              <div className="mt-3 rounded-lg bg-destructive/10 p-2 text-xs text-destructive">{candidate.rejectReason}</div>
            )}

            <div className="marshall-display mt-5 text-xs text-muted-foreground">Действия</div>
            <div className="mt-2 space-y-2">
              <Button variant="outline" className="h-auto w-full justify-start gap-2 whitespace-normal py-2" data-testid="button-schedule-interview"
                onClick={async () => { await apiRequest("POST", `/api/candidates/${id}/messages`, { channel: "telegram", text: "Приглашаем вас на собеседование. Когда вам удобно?", isRead: 1 }); queryClient.invalidateQueries({ queryKey: ["/api/candidates", id, "messages"] }); toast({ title: "Приглашение на собеседование отправлено" }); }}>
                <CalendarPlus className="h-4 w-4 shrink-0" /> <span className="text-left leading-tight">Запланировать интервью</span>
              </Button>
              <Button variant="outline" className="w-full justify-start gap-2" data-testid="button-call" onClick={copyPhone}>
                <PhoneCall className="h-4 w-4" /> Позвонить
              </Button>
              <Button variant="outline" className="w-full justify-start gap-2" data-testid="button-archive"
                onClick={() => { changeStage("reserve"); toast({ title: "Кандидат перемещён в резерв" }); }}>
                <Archive className="h-4 w-4" /> В резерв
              </Button>
              <Button variant="destructive" className="w-full justify-start gap-2" data-testid="button-reject" onClick={() => setRejectOpen(true)}>
                <X className="h-4 w-4" /> Отказать
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {/* Reject dialog */}
      <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Причина отказа</DialogTitle></DialogHeader>
          <Textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="Укажите причину отказа..." data-testid="textarea-reject" />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectOpen(false)} data-testid="button-cancel-reject">Отмена</Button>
            <Button variant="destructive" data-testid="button-confirm-reject"
              onClick={async () => { await changeStage("rejected", rejectReason); setRejectOpen(false); setRejectReason(""); toast({ title: "Кандидат отклонён" }); }}>
              Отказать
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New task dialog */}
      <Dialog open={newTaskOpen} onOpenChange={setNewTaskOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Новая задача</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="mb-1 block text-xs text-muted-foreground">Назначить</label>
              <Select value={newTask.assigneeId} onValueChange={(v) => setNewTask((p) => ({ ...p, assigneeId: v }))}>
                <SelectTrigger data-testid="select-task-assignee"><SelectValue placeholder="Выберите ответственного" /></SelectTrigger>
                <SelectContent>
                  {(crmUsers ?? []).map((u) => (
                    <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="mb-1 block text-xs text-muted-foreground">Название *</label>
              <Input value={newTask.title} onChange={(e) => setNewTask((p) => ({ ...p, title: e.target.value }))} placeholder="Название задачи" data-testid="input-task-title" />
            </div>
            <div>
              <label className="mb-1 block text-xs text-muted-foreground">Описание</label>
              <Textarea value={newTask.description} onChange={(e) => setNewTask((p) => ({ ...p, description: e.target.value }))} placeholder="Описание..." className="min-h-[80px]" />
            </div>
            <div>
              <label className="mb-1 block text-xs text-muted-foreground">Срок *</label>
              <Input type="datetime-local" value={newTask.dueAt} onChange={(e) => setNewTask((p) => ({ ...p, dueAt: e.target.value ? new Date(e.target.value).toISOString() : "" }))} data-testid="input-task-due" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewTaskOpen(false)}>Отмена</Button>
            <Button onClick={createTask} data-testid="button-create-task">Создать</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

// Panel for Telegram deep-link generation
function TelegramLinkPanel({ candidateId }: { candidateId: string }) {
  const [linkData, setLinkData] = useState<{ token: string; deepLink: string; botUsername: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  async function generate() {
    setLoading(true);
    try {
      const res = await apiRequest("POST", `/api/candidates/${candidateId}/link-token`, {});
      const data = await res.json() as { token: string; deepLink: string; botUsername: string };
      setLinkData(data);
    } catch {
      toast({ title: "Ошибка генерации ссылки", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  if (!linkData) {
    return (
      <Button size="sm" variant="outline" className="h-7 w-full gap-1 text-xs" onClick={generate} disabled={loading} data-testid="button-gen-link-token">
        <Link2 className="h-3 w-3" /> {loading ? "Генерирую..." : "Создать ссылку"}
      </Button>
    );
  }

  return (
    <div className="space-y-2">
      <div className="break-all rounded bg-muted px-2 py-1.5 text-[10px]">{linkData.deepLink}</div>
      <Button
        size="sm"
        variant="outline"
        className="h-7 w-full gap-1 text-xs"
        onClick={() => {
          navigator.clipboard.writeText(linkData.deepLink).catch(() => {});
          toast({ title: "Ссылка скопирована" });
        }}
        data-testid="button-copy-link"
      >
        <Copy className="h-3 w-3" /> Скопировать
      </Button>
    </div>
  );
}
