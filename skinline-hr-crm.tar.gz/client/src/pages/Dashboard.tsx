import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Users, UserPlus, CheckCircle2, Briefcase, MessageSquare, PhoneCall, StickyNote, History, CalendarPlus, FileText, TrendingUp } from "lucide-react";
import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { STAGES, SOURCES } from "@/lib/crm";
import { cn } from "@/lib/utils";
import type { Activity } from "@shared/schema";

interface Stats {
  totalCandidates: number;
  byStage: Record<string, number>;
  bySource: Record<string, number>;
  hiredThisMonth: number;
  officialThisMonth: number;
  newThisWeek: number;
  inWork: number;
  activeVacancies: number;
}

const ACT_ICONS: Record<string, React.ElementType> = {
  stage_change: History, note: StickyNote, call: PhoneCall,
  message: MessageSquare, document_uploaded: FileText, interview_scheduled: CalendarPlus,
};

function Kpi({ icon: Icon, label, value, tint }: { icon: React.ElementType; label: string; value: number; tint: string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <div className="marshall-display text-[11px] text-muted-foreground">{label}</div>
          <div className="font-display mt-1.5 text-2xl leading-none" data-testid={`kpi-${label}`}>{value}</div>
        </div>
        <div className={cn("flex h-11 w-11 items-center justify-center rounded-xl", tint)}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<Stats>({ queryKey: ["/api/dashboard/stats"] });

  if (isLoading || !stats) {
    return <Layout title="Дашборд"><div className="grid grid-cols-2 gap-4 p-8 lg:grid-cols-4">{[0,1,2,3].map(i => <Skeleton key={i} className="h-24 rounded-xl" />)}</div></Layout>;
  }

  const maxStage = Math.max(...STAGES.map((s) => stats.byStage[s.key] ?? 0), 1);
  const totalSource = Object.values(stats.bySource).reduce((a, b) => a + b, 0) || 1;

  return (
    <Layout title="Дашборд">
      <div className="space-y-5 p-5 md:p-8">
        {/* KPIs */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Kpi icon={Users} label="Всего кандидатов" value={stats.totalCandidates} tint="bg-secondary/40 text-primary" />
          <Kpi icon={UserPlus} label="Новых за неделю" value={stats.newThisWeek} tint="bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-300" />
          <Kpi icon={TrendingUp} label="В работе" value={stats.inWork ?? 0} tint="bg-cyan-100 text-cyan-600 dark:bg-cyan-500/20 dark:text-cyan-300" />
          <Kpi icon={CheckCircle2} label="Трудоустроено за 30 дн." value={stats.officialThisMonth ?? stats.hiredThisMonth} tint="bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-300" />
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Funnel — 14 bars */}
          <Card className="p-5 lg:col-span-2">
            <h2 className="mb-4 text-sm">Воронка (14 этапов)</h2>
            <div className="space-y-2">
              {STAGES.map((s) => {
                const count = stats.byStage[s.key] ?? 0;
                return (
                  <div key={s.key} className="flex items-center gap-3">
                    <div className="w-36 shrink-0 truncate text-xs text-muted-foreground">{s.label}</div>
                    <div className="flex-1">
                      <div className="h-6 overflow-hidden rounded-lg bg-muted">
                        <div className={cn("flex h-full items-center rounded-lg px-2 text-xs font-medium text-white transition-all", s.color)}
                          style={{ width: `${Math.max((count / maxStage) * 100, count > 0 ? 8 : 0)}%` }}>
                          {count > 0 && count}
                        </div>
                      </div>
                    </div>
                    <div className="w-8 text-right text-sm font-medium" data-testid={`funnel-${s.key}`}>{count}</div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Sources */}
          <Card className="p-5">
            <h2 className="mb-4 text-sm">Источники</h2>
            <div className="space-y-3">
              {Object.entries(SOURCES).map(([key, src]) => {
                const count = stats.bySource[key] ?? 0;
                const pct = Math.round((count / totalSource) * 100);
                return (
                  <div key={key}>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span className="inline-flex items-center gap-2">
                        <span className={cn("h-3 w-3 rounded-full", src.className.split(" ")[0])} />
                        {src.label}
                      </span>
                      <span className="font-medium" data-testid={`source-${key}`}>{count} · {pct}%</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-muted">
                      <div className={cn("h-full rounded-full", src.className.split(" ")[0])} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Recent activity */}
        <RecentActivity />
      </div>
    </Layout>
  );
}

function RecentActivity() {
  const { data: recent } = useQuery<Activity[]>({ queryKey: ["/api/dashboard/recent"] });
  return (
    <Card className="p-5">
      <h2 className="mb-4 text-sm">Последние действия</h2>
      <div className="space-y-3" data-testid="recent-activities">
        {(recent ?? []).length === 0 && <div className="text-sm text-muted-foreground">Нет недавних действий</div>}
        {(recent ?? []).map((a) => {
          const Icon = ACT_ICONS[a.type] ?? History;
          return (
            <Link key={a.id} href={`/candidates/${a.candidateId}`} className="flex items-center gap-3 rounded-lg px-2 py-1.5 hover-elevate" data-testid={`activity-${a.id}`}>
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary/40 text-primary">
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm">{a.description}</div>
              </div>
              <div className="shrink-0 text-xs text-muted-foreground">{fmtRel(a.createdAt)}</div>
            </Link>
          );
        })}
      </div>
    </Card>
  );
}

function fmtRel(iso: string) {
  try { return format(new Date(iso), "d MMM, HH:mm", { locale: ru }); } catch { return ""; }
}
